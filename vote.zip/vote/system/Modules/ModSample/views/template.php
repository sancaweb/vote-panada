<!DOCTYPE html>

<html>
<head>
    <title>Hello world from module <?php echo $moduleName;?></title>
</head>
<body>
<p><?php echo $title;?></p>
<p>Back to <a href="<?php echo $this->uri->baseUri;?>">home</a>.</p>
</body>
</html>