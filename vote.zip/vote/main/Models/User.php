<?php
namespace Models;
use Resources, Models;


class User {
    
    //panggil library model terlebih dahulu
    public function __construct() {
        $this->db = new Resources\Database();
    }
    
    //view semua user
    public function view($paging = 1, $limit = 10){
        $offset = ($limit * $paging) - $limit;
        return $this->db->results("SELECT * FROM user ORDER BY id DESC LIMIT $offset, $limit");
    }
    
    //hitung jumlah total phonebook
    public function total(){	
	return $this->db->getVar("SELECT COUNT(username) FROM user");
    }
    
    //view user sesuai ID
    public function viewuser($id){
        return $this->db->row("SELECT * FROM user WHERE ID='".$id."'");
    }
    
    //cek username, Password dan grup
    public function cek ($username,$password){
        return $this->db->row("SELECT * FROM user WHERE username='".$username."' AND password='".$password."'");
    }
    
    //cek password
    public function cekpass($id,$oldpass){
        return $this->db->row("SELECT * FROM user WHERE id='".$id."' AND password='".$oldpass."'");
    }
    
    //cek user
    public function cekuser($username){
        return $this->db->row("SELECT username FROM user WHERE username='".$username."'");
    }
    
    //insert user
    public function input($data){
        return $this->db->insert('user',$data);
    }
    
    //update user
    public function update($data,$id){
        return $this->db->update('user',$data,array('id'=>$id));
    }
    
    //view grup
    public function viewgrup(){
        return $this->db->results("SELECT * FROM usergrup ORDER BY grup ASC");
    }
    
    //delete
    public function hapus($id){
        return $this->db->delete("user",array('id'=>$id));
    }
       
}