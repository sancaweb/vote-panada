<?php
namespace Models;
use Resources, Models;


class Phonebook {
    
    //panggil library model terlebih dahulu
    public function __construct() {
        $this->db = new Resources\Database();
    }
    
    //tampilkan phonebook    
    public function getpbks($paging = 1, $limit = 10){
	
	$offset = ($limit * $paging) - $limit;
	
	$results = $this->db->results("SELECT * FROM pbk ORDER BY Name ASC LIMIT $offset, $limit");
        
        return $results;
    }
    
    //hitung jumlah total phonebook
    public function total(){
	
	return $this->db->getVar("SELECT COUNT(Name) FROM pbk");
    }    
    
    //input phonebook
    public function inputpbk($datapbk){
        $data = $this->db->insert("pbk",$datapbk);
        return $data;
    }
    
    //ambil data phonebook sesuai grup
    public function getpbk($grup){
        return $this->db->results("SELECT * FROM pbk WHERE grup='".$grup."'");
    }
    
    //view phonebook sesuai id
    public function viewpbk($id){
        return $this->db->row("SELECT * FROM pbk WHERE ID='".$id."'");
    }
    
    //view phonebook sesuai number dari inbox
    public function viewpbk2($nomernya){
        return $this->db->row("SELECT Name,grup FROM pbk WHERE Number='".$nomernya."'");
    }
    
    //view phonebook sesuai nama
    public function viewpbk3($name){
        return $this->db->row("SELECT Number FROM pbk WHERE Name='".$name."'");
    }
    
    //Edit (update) phonebook
    public function update($data,$id){
        return $this->db->update("pbk",$data,array('ID'=>$id));
    }
    
    //edit (update) phonebook nama grup nya
    public function update2($data,$namaawal){
        return $this->db->update("pbk",$data,array('grup'=>$namaawal));
    }
    
    //Hapus phonebook
    public function hapus($id){
        return $this->db->delete("pbk",array('ID'=>$id));
    }
    
    //Add grup phonebook
    public function addgrup($datagrup){
        $data = $this->db->insert("pbk_groups",$datagrup);
        return $data;
    }
    
    //tampilkan grup phonebook
    public function getgrup(){
        $data=$this->db->results("SELECT * FROM pbk_groups ORDER BY Name ASC");
        return $data;
    }
    
    //cek keberadaan grup
    public function cekgrup($name){
        return $this->db->row("SELECT Name FROM pbk_groups WHERE Name='".$name."'");
    }
    
    //view grup sesuai id
    public function viewgrup($id){
        return $this->db->row("SELECT * FROM pbk_groups WHERE ID='".$id."'");
    }
    
    //Edit (update) grup
    public function updategrup($data,$id){
        return $this->db->update("pbk_groups",$data,array('ID'=>$id));
    }
    
    //empty phonebook
    public function emptypbk(){
        return $this->db->query("TRUNCATE TABLE pbk");
    }
    
    //hapus grup
    
    public function delgrup($id){
	return $this->db->delete("pbk_groups",array('ID'=>$id));
	}
}
