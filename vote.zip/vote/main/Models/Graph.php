<?php
namespace Models;
use Resources, Models;


class Graph {
    
    //panggil library model terlebih dahulu
    public function __construct() {
        $this->db = new Resources\Database();
    }

    //tampilkan semua  data polling
    public function graph() {
        $data = $this->db->results("SELECT * FROM data_polling");
        return $data;
    }
    public function allvote(){
        $data=$this->db->getVar("SELECT sum(vote) FROM data_polling");
        return $data;
    }
    
    
       
}
