<?php
namespace Models;
use Resources, Models;


class Sms {
    
    //panggil library model terlebih dahulu
    public function __construct() {
        $this->db = new Resources\Database();
    }

    //tampilkan semua inbox
    public function inbox($page = 1, $limit = 10) {
        $offset = ($limit * $page) - $limit;        
        $data = $this->db->results("SELECT SenderNumber,TextDecoded,ReceivingDateTime,ID FROM inbox ORDER BY ID DESC LIMIT $offset, $limit");
        return $data;
    }
    
    //total inbox
    public function totinbox(){
        return $this->db->getVar("SELECT COUNT(ID) FROM inbox");
    }
    
    
    //tampilkan inbox sesuai ID
    public function viewinbox($id){
        return $this->db->row("SELECT SenderNumber,TextDecoded,ReceivingDateTime,ID FROM inbox WHERE ID='".$id."'");
    }
    
    //hapus inbox
    public function hapusinbox($id){
        return $this->db->delete("inbox",array('ID'=>$id));
    }
    
    //tampilkan inbox processed yang false
    public function inboxVote(){
        $data = $this->db->results("SELECT * FROM inbox WHERE Processed='false'");
        return $data;
    }
    
    //update inbox
    public function updateInbox($data,$id){
        $data=$this->db->update("inbox",$data,array('ID'=>$id));
    }
    
    //empty table inbox
    public function emptyinbox(){
        return $this->db->query("TRUNCATE TABLE inbox");
    }
    
    //tampilkan semua sentitems
    public function sentitems($page = 1, $limit = 10) {
        $offset = ($limit * $page) - $limit;
        $data = $this->db->results("SELECT DestinationNumber,TextDecoded,SendingDateTime,ID FROM sentitems ORDER BY id DESC LIMIT $offset, $limit");
        return $data;
    }
    
    //total sentitems
    public function totsent(){
        return $this->db->getVar("SELECT COUNT(ID) FROM sentitems");
    }
    
    //tampilkan sentitems sesuai ID
    public function viewsentitems($id){
        return $this->db->row("SELECT DestinationNumber,TextDecoded,SendingDateTime,ID FROM sentitems WHERE ID='".$id."'");
    }
    
    //hapus sentitems
    public function hapussentitems($id){
        return $this->db->delete("sentitems",array('ID'=>$id));
    }
    
    //input outbox (untuk mengirim pesan)
    public function inputOutbox($data){
        return $this->db->insert("outbox",$data);
    }
    
    //tampilkan semua outbox
    public function outbox($page = 1, $limit = 10) {
        $offset = ($limit * $page) - $limit;
        $data = $this->db->results("SELECT DestinationNumber,TextDecoded,SendingDateTime,ID FROM outbox ORDER BY ID DESC LIMIT $offset, $limit");
        return $data;
    }
    
    //total outbox
    public function totoutbox(){
        return $this->db->getVar("SELECT COUNT(ID) FROM outbox");
    }
    
    //tampilkan outbox sesuai ID
    public function viewoutbox($id){
        return $this->db->row("SELECT DestinationNumber,TextDecoded,SendingDateTime,ID FROM outbox WHERE ID='".$id."'");
    }
    
    //hapus sentitems
    public function hapusoutbox($id){
        return $this->db->delete("outbox",array('ID'=>$id));
    }
       
}