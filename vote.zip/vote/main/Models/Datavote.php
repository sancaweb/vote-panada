<?php
namespace Models;
use Resources, Models;


class Datavote {
    
    //panggil library model terlebih dahulu
    public function __construct() {
        $this->db = new Resources\Database();
    }
    //mengambil data pilihan
    public function pilihan($pilihan){
        $data=$this->db->results("Select pilihan from data_polling where pilihan='".$pilihan."'");
        return $data; 
    }
    
    //mengambil data pilihan sesuai id
    public function pilihannya($id){
        return $this->db->row("SELECT * FROM data_polling WHERE id='".$id."'");
    }
    
    //mengambil nilai vote terakhir 
    public function jmlVote($pilihannya){
        $data=$this->db->row("SELECT vote FROM data_polling WHERE pilihan='".$pilihannya."'");
        return $data;
    }
    
    //update data_polling
    public function updatepoll($data,$pilihan){
        $data=$this->db->update("data_polling",$data,array('pilihan'=>$pilihan));
        return $data;
    }
    
    //update data polling2
    public function updatepoll2($data,$id){
        return $this->db->update("data_polling",$data,array('id'=>$id));
    }
    
    //view semua data pilihan
    public function view(){
        return $this->db->results("SELECT * FROM data_polling ORDER BY urut ASC");
    }
    
    //view semua warna
    public function warna(){
        return $this->db->results("SELECT warna FROM warna ORDER BY warna ASC");
    }
    
    //input data_polling
    public function inputvote($data){
        return $this->db->insert("data_polling",$data);
    }    
    
     //delete data_polling
    public function delete($id){
        return $this->db->delete("data_polling",array('id'=>$id));
    }
    
    //view setting vote
    public function viewset(){
        return $this->db->row("SELECT * FROM setvote");
    }
    
    //update setting
    public function updateset($data,$id){
        return $this->db->update("setvote",$data,array('id'=>$id));
    }
}