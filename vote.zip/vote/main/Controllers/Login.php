<?php
namespace Controllers;
use Resources, Models,Controllers;

class Login extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->request=new Resources\Request;
        $this->user=new Models\User;
        $this->session = new Resources\Session;
    }
    public function index(){
        $page=array(
            'title'=>'Login Form'
            
        );
        $this->output(TMP.'login',$page);
        
    }
    
    public function proseslogin(){
        
        if($_POST){
        $kode=KODE;
        $username=$this->request->post('username',FILTER_SANITIZE_MAGIC_QUOTES);
        $password=md5($this->request->post('password')).md5($kode);
        $grup=$this->user->cek($username, $password);
        $cekuser=$this->user->cek($username, $password);
        
        if ($cekuser){
            $data=array(
                'username'=>$username,
                'grup'=>$grup->grup,
                'kode'=>md5($kode),
            );
            $this->session->setValue($data);
            $this->redirect('home');
        }else{
            $this->index();
        }
        $page=array(
            'title'=>'Login Form',
            'username'=>$username,
            'password'=>$password,
            
        );
        $this->output(TMP.'login',$page);
        }else{
            $this->index();
        }
        
        
    }
    
    //Untuk logout
    public function logout(){
        $this->session->destroy();
        $this->redirect('home');
    }
    
}