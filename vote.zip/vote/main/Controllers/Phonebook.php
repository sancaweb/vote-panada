<?php
namespace Controllers;
use Resources, Models;

class Phonebook extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->pbk=new Models\Phonebook;
        $this->request=new Resources\Request;
        $this->session=new Resources\Session;
    }
    
    public function index($paging=1)
    {  
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'pbk' => $this->pbk->getpbks($paging, $limit),
            'jumlah' => $this->pbk->total(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'phonebook/index/%#%/',
		    'total' => $this->pbk->total(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
        
            'konten'=>konten.'phonebook',
            'title' => 'Phone book'.TTL,
            'refresh'=>$this->uri->baseUri.'phonebook'
        );
            $this->output(TMP.'index',$page);
        }else{
            $this->redirect('login');
        }
    }
    
    public function input(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if ($_POST){
            $nomer=$this->request->post('notlp');
        
        $page=array(
            'konten'=>konten.'inputphonebook',
            'title' => 'Input Phonebook'.TTL,
            'grup'=> $this->pbk->getgrup(),
            'nomer'=>$nomer,
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'inputphonebook',
            'title' => 'Input Phonebook'.TTL,
            'grup'=> $this->pbk->getgrup(),
        );
            $this->output(TMP.'index',$page);
            
        }
        }else{
            $this->redirect('login');
        }
    }
    public function prosesinput(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if ($_POST){
        $nama=ucwords($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));
        $notlp=$this->request->post('notlp',FILTER_SANITIZE_NUMBER_INT);
        $operator=$this->request->post('operator');
        
        //Proses merubah +62 ke 0
        if(!preg_match('/[^+0-9]/',trim($notlp))){
        // cek apakah no hp karakter 1-3 adalah +62
        if(substr(trim($notlp), 0, 3)=='+62'){
            $notlp=$notlp;
        }
        // cek apakah no hp karakter 1 adalah 0
        elseif(substr(trim($notlp), 0, 1)=='0'){
            $notlp = '+62'.substr(trim($notlp), 1);
        }
        }
        // end proses perubahan angka
        
        $grup=$this->request->post('grup');
        if ($grup=='0'){
            $page=array(
            'konten'=>konten.'inputphonebook',
            'title' => 'Input Phonebook'.TTL,
            'grup'=> $this->pbk->getgrup(),
            'pesan'=>'<div class="warning_box">Silahkan isikan Pilihan grup!</div>'
        );
        $this->output(TMP.'index',$page);
        }else{
            $datapbk=array(
            'Name'=>$nama,
            'Number'=>$notlp,
            'grup'=>$grup,
            'operator'=>$operator,
        );
        
        $page=array(
            'konten'=>konten.'inputphonebook',
            'title' => 'Input Phonebook'.TTL,
            'grup'=> $this->pbk->getgrup(),
            'pesan'=>'<div class="valid_box">Selamat anda berhasil input Phonebook</div>'
        );
        $this->pbk->inputpbk($datapbk);
        $this->output(TMP.'index',$page);
        }
        }else{
            $this->input();
        }
        }else{
            $this->redirect('login');
        }
        
    }
    
    //view phonebook sesuai ID
    public function viewpbk($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if (isset($id)){
        $id=(int) base64_decode($id);
        $page=array(
            'konten'=>konten.'viewphonebook',
            'title'=>'View detail Phonebook'.TTL,
            'pbk'=>$this->pbk->viewpbk($id),
        );
        $this->output(TMP.'index',$page);
    
        }else{
        $page=array(
            'konten'=>konten.'viewphonebook',
            'title'=>'View detail Phonebook'.TTL
        );
        $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    }
    
    //edit phonebook
    public function edit($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if (isset($id)){
        $id=(INT)  base64_decode($id);
        $page=array(
            'konten'=>konten.'editphonebook',
            'title'=>'Edit Phonebook'.TTL,
            'pbk'=>$this->pbk->viewpbk($id),
            'grup'=>$this->pbk->getgrup(),
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'editphonebook',
            'title'=>'View detail Phonebook'.TTL,
        );
        $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    }
    
    //proses edit/update
    public function prosesedit($paging=1){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if($_POST){
        $nama=ucwords($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));
        $notlp=$this->request->post('notlp',FILTER_SANITIZE_NUMBER_INT);
        $operator=$this->request->post('operator');
        //Proses merubah +62 ke 0
        if(!preg_match('/[^+0-9]/',trim($notlp))){
        // cek apakah no hp karakter 1-3 adalah +62
        if(substr(trim($notlp), 0, 3)=='+62'){
            $notlp=$notlp;
        }
        // cek apakah no hp karakter 1 adalah 0
        elseif(substr(trim($notlp), 0, 1)=='0'){
            $notlp = '+62'.substr(trim($notlp), 1);
        }
        }
        // end proses perubahan angka
        $grup=$this->request->post('grup');
        $id=$this->request->post('id');
        if ($grup=='0'){
            $page=array(
                'konten'=>konten.'editphonebook',
                'title'=>'Edit Phonebook'.TTL,
                'pbk'=>$this->pbk->viewpbk($id),
                'grup'=>$this->pbk->getgrup(),
                'pesan'=>'<div class="warning_box">Silahkan isikan Pilihan grup!</div>',
        );
        $this->output(TMP.'index',$page);
            
        }else{
        $data=array(
            'Name'=>$nama,
            'Number'=>$notlp,
            'grup'=>$grup,
            'operator'=>$operator,
        );
        $this->pbk->update($data, $id);
        $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'pbk' => $this->pbk->getpbks($paging, $limit),
            'jumlah' => $this->pbk->total(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'phonebook/index/%#%/',
		    'total' => $this->pbk->total(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
        
            'konten'=>konten.'phonebook',
            'title' => 'Phone book'.TTL,
            'refresh'=>$this->uri->baseUri.'phonebook',
            'pesan'=>'<div class="valid_box">Selamat anda telah berhasil melakukan edit data</div>'
        );
            $this->output(TMP.'index',$page);
        }
        }else{
            $this->index();
        }
        }else{
            $this->redirect('login');
        }
    }
    
    //hapus phonebook
    public function hapus($paging=1,$id){
        
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if (isset($id)){
        $id=(int) base64_decode($id);
        $this->pbk->hapus($id);
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'pbk' => $this->pbk->getpbks($paging, $limit),
            'jumlah' => $this->pbk->total(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'phonebook/index/%#%/',
		    'total' => $this->pbk->total(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
            'konten'=>konten.'phonebook',
            'title' => 'Phone book'.TTL,
            'pbk'=> $this->pbk->getpbks(),
            'refresh'=>$this->uri->baseUri.'phonebook',
            'pesan'=>'<div class="valid_box">Selamat anda telah berhasil Menghapus data</div>'
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'phonebook',
            'title' => 'Phone book'.TTL,
            'pbk'=> $this->pbk->getpbks(),
            'refresh'=>$this->uri->baseUri.'phonebook',
            'pesan'=>'<div class="warning_box">Tidak ada user yang terhapus</div>'
        );
            $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    }
    
    //empty phonebook
    public function emptypbk(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if ($this->session->getValue('grup')=="Admin"){
        $this->pbk->emptypbk();
        $this->index();
        
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan inputan.',
				);
				$this->output('errors/error',$page);
	}
        }else{
            $this->redirect('login');
        }
    }
}
