<?php
namespace Controllers;
use Resources, Models;

class Setvote extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->pbk=new Models\Phonebook;
        $this->datavote=new Models\Datavote;
        $this->request=new Resources\Request;
        $this->sms = new Models\Sms;
        $this->session=new Resources\Session;
    }
    
    public function index()
    { if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
		if($this->session->getValue('grup')=="Admin"){
        $page=array(
            'setvote'=>$this->datavote->viewset(),
            'konten'=>konten.'vote',
            'title' => 'Vote Settings'.TTL,
            'pilihan'=>$this->datavote->view(),
            'warna'=>$this->datavote->warna(),
        );
            $this->output(TMP.'index',$page);
            
		}else{
			$page=array(
            'setvote'=>$this->datavote->viewset(),
            'konten'=>konten.'vote',
            'title' => 'Vote Settings'.TTL,
            'pilihan'=>$this->datavote->view(),
            'warna'=>$this->datavote->warna(),
            'pesan'=>'<div class="warning_box">Hanya user yang berstatus "Admin" yang dapat melakukan setting Vote.</div>'
        );
            $this->output(TMP.'index',$page);
			}
    }else{
        $this->redirect('login');
    }
    }
    public function input(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if($this->session->getValue('grup')=="Admin"){
        if ($_POST){
        $nama=strtoupper($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));
        $norut=$this->request->post('norut',FILTER_SANITIZE_NUMBER_INT);
        $keterangan=ucwords($this->request->post('keterangan'));
                
            $data=array(
                'pilihan'=>$nama,
                'urut'=>$norut,
                'keterangan'=>$keterangan,
            );
        $this->datavote->inputvote($data);
        $page=array(
            'setvote'=>$this->datavote->viewset(),
            'konten'=>konten.'vote',
            'title' => 'Vote Settings'.TTL,
            'pilihan'=>$this->datavote->view(),
            'warna'=>$this->datavote->warna(),
            'refresh'=>$this->uri->baseUri."setvote",
            'pesan'=>'<div class="valid_box">Selamat anda berhasil input Pilihan</div>'
        );
        
        $this->output(TMP.'index',$page);
        
        }else{
            $this->index();
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan setting Vote.',
				);
				$this->output('errors/error',$page);
	}
        //disini
        }else{
            $this->redirect('login');
        }
        
    }
    
    //edit pilihan
    public function edit($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        if (isset($id)){
            $id=(INT)  base64_decode($id);
            $pilihannya=$this->datavote->pilihannya($id);
            $page=array(
                'setvote'=>$this->datavote->viewset(),               
                'konten'=>konten.'vote',
                'title'=>'Vote Settings'.TTL,
                'pilihan'=>$this->datavote->view(),
                'warna'=>$this->datavote->warna(),
                'pilihannya'=>$pilihannya,
            );
            $this->output(TMP.'index',$page);
            }else{
                $this->index();
            }
		}else{
			
			$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan setting Vote.',
				);
				$this->output('errors/error',$page);
			}
            
        }else{
            $this->redirect('login');
        }
    }
    
    //proses edit/update
    public function prosesedit(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        
        if($this->session->getValue('grup')=="Admin"){
        if($_POST){
        $nama=strtoupper($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));
        $norut=$this->request->post('norut',FILTER_SANITIZE_NUMBER_INT);
        $keterangan=ucwords($this->request->post('keterangan'));
        $id=$this->request->post('id');
        
        $data=array(
                'pilihan'=>$nama,
                'urut'=>$norut,
                'keterangan'=>$keterangan,
            );
        $this->datavote->updatepoll2($data, $id);
        $page=array(
                'setvote'=>$this->datavote->viewset(),
                'konten'=>konten.'vote',
                'title'=>'Vote Settings'.TTL,
                'pilihan'=>$this->datavote->view(),
                'warna'=>$this->datavote->warna(),
                'pesan'=>'<div class="valid_box">Anda berhasil melakukan edit</div>',
                'refresh'=>$this->uri->baseUri."setvote",
            );
            $this->output(TMP.'index',$page);
        
        }else{
            $this->index();
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan setting Vote.',
				);
				$this->output('errors/error',$page);
		}
        }else{
            $this->redirect('login');
        }
    }
    
    //hapus phonebook
    public function delete($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        if (isset($id)){
                $id=(int) base64_decode($id);
                $this->datavote->delete($id);
                $page=array(
                    'setvote'=>$this->datavote->viewset(),
                    'konten'=>konten.'vote',
                    'title'=>'Vote Settings'.TTL,
                    'pilihan'=>$this->datavote->view(),
                    'warna'=>$this->datavote->warna(),
                    'pesan'=>'<div class="valid_box">Anda berhasil menghapus data</div>',
                    'refresh'=>$this->uri->baseUri."setvote",
                );
            $this->output(TMP.'index',$page);
        }else{
            $page=array(
                'setvote'=>$this->datavote->viewset(),
                'konten'=>konten.'vote',
                'title'=>'Vote Settings'.TTL,
                'pilihan'=>$this->datavote->view(),
                'warna'=>$this->datavote->warna(),
                'pesan'=>'<div class="warning_box">Tidak ada data yang terhapus</div>',
                'refresh'=>$this->uri->baseUri."setvote",
            );
            $this->output(TMP.'index',$page);
        }
        }else{
			$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan setting Vote.',
				);
				$this->output('errors/error',$page);
			}
        
        }else{
            $this->redirect('login');
        }
    }
    
    //voting setting
    public function updateset(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if($this->session->getvalue('grup')=="Admin"){
        if ($_POST){
        $format=strtoupper($this->request->post('format'));
        $status=$this->request->post('stt');
        $judul=ucwords($this->request->post('judul'));
        $warna=$this->request->post('warna');
        
        $id='1';
        $data=array(
            'format'=>$format,
            'status'=>$status,
            'judul'=>$judul,
            'warna'=>$warna,
        );
        $this->datavote->updateset($data, $id);
        if ($status=='1'){
                 $datasms=$this->sms->inboxVote();
                 if ($datasms){
            foreach ($datasms as $datasms){
                $data=array(
                            'Processed'=>'true',
                        );
            $id2=$datasms->ID;
            $this->sms->updateInbox($data, $id2);
            }
            
            }
            }
        
        $page=array(
                    'setvote'=>$this->datavote->viewset(),
                    'konten'=>konten.'vote',
                    'title'=>'Vote Settings'.TTL,
                    'pilihan'=>$this->datavote->view(),
                    'warna'=>$this->datavote->warna(),
                    'pesan'=>'<div class="valid_box">Anda berhasil update settings</div>',
                    'refresh'=>$this->uri->baseUri."setvote",
                );
            $this->output(TMP.'index',$page);
        }else{
            $this->index();
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan setting Vote.',
				);
				$this->output('errors/error',$page);
		}
        
        }else{
            $this->redirect('login');
        }
    }
}
