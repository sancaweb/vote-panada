<?php
namespace Controllers;
use Resources, Models;

class Grup extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->pbk=new Models\Phonebook;
        $this->request=new Resources\Request;
        $this->session = new Resources\Session;
    }
    public function index()
    {    
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        $page=array(
            'konten'=>konten.'grup',
            'title' => 'Phonebook Group'.TTL,
            'refresh'=>$this->uri->baseUri.'grup',
            'grup'=>$this->pbk->getgrup(),
        );
        $this->output(TMP.'index',$page);
	}else{
		$page=array(
            'konten'=>konten.'grup',
            'title' => 'Phonebook Group'.TTL,
            //'refresh'=>$this->uri->baseUri.'grup',
            'pesan'=>'<div class="warning_box">Hanya user berstatus "Admin" yang dapat melakukan pengaturan grup phonebook.</div>',
            'grup'=>$this->pbk->getgrup(),
        );
        $this->output(TMP.'index',$page);
	}
        }else{
            $this->redirect('login');
        }
    }
    
    public function input(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        if ($_POST){
        $nama=ucwords($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));        
        $cekgrup=$this->pbk->cekgrup($nama);
        
        if ($cekgrup){
            $page=array(
                'konten'=>konten.'grup',
                'title' => 'Phonebook Group'.TTL,
                'grup'=>$this->pbk->getgrup(),
                'refresh'=>$this->uri->baseUri.'grup',
                'pesan'=>'<div class="warning_box">Maaf grup yang anda masukan sudah ada.</div>'
            );
            $this->output(TMP.'index',$page);
            
        }else{
            $datagrup=array(
                'Name'=>$nama,
            );
            $this->pbk->addgrup($datagrup);
            
            $page=array(
                'konten'=>konten.'grup',
                'title' => 'Phonebook Group'.TTL,
                'grup'=>$this->pbk->getgrup(),
                'refresh'=>$this->uri->baseUri.'grup',
                'pesan'=>'<div class="valid_box">Grup telah berhasil di input.</div>'
            );
            $this->output(TMP.'index',$page);
        }
        }else{
            $this->index();
        }
        
	}else{
			$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan pengaturan grup phonebook.',
				);
				$this->output('errors/error',$page);
	}
        
        }else{
            $this->redirect('login');
        }
        
    }
        
    //edit grup
    public function edit($id){
        if ($this->session->getValue('username') == TRUE AND $this->session->getValue('kode') == md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        if (isset($id)){
        $id=(INT)  base64_decode($id);
        $name=$this->pbk->viewgrup($id);
        $page=array(
            'konten'=>konten.'grup',
            'title'=>'Edit Grup'.TTL,
            'name'=>$name,
            'grup'=>$this->pbk->getgrup(),
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
                'konten'=>konten.'grup',
                'title'=>'Edit Grup'.TTL,
                'grup'=>$this->pbk->getgrup(),
                'pesan'=>'<div class="warning_box">Harap tekan tombol "Edit" terlebih dahulu ..!</div>'
        );
        $this->output(TMP.'index',$page);
        }
        
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan pengaturan Grup Phonebook.',
				);
				$this->output('errors/error',$page);
		}
        }else{
            $this->redirect('login');
        }
    }
    
    //proses edit/update
    public function prosesedit(){
        if ($this->session->getValue('username') == TRUE AND $this->session->getValue('kode') == md5('sanca')) {
			if ($this->session->getValue('grup')=="Admin"){
        if($_POST){
        $nama=ucwords($this->request->post('nama',FILTER_SANITIZE_MAGIC_QUOTES));
        $id=$this->request->post('id');
        $namaawal=ucwords($this->request->post('namaawal'));
        $data=array(
            'Name'=>$nama,
        );
        $this->pbk->updategrup($data, $id);
        
        $data2=array(
            'grup'=>$nama,
        );
        $this->pbk->update2($data2, $namaawal);
        $page=array(
            'konten'=>konten.'grup',
            'title' => 'Phonebook Group'.TTL,
            'refresh'=>$this->uri->baseUri.'grup',
                'grup'=>$this->pbk->getgrup(),
            'pesan'=>'<div class="valid_box">Selamat anda telah berhasil melakukan edit data</div>'
        );
        $this->output(TMP.'index',$page);
        }else{
            $this->index();
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan edit data.',
				);
				$this->output('errors/error',$page);
		}
        }else{
            $this->redirect('login');
        }
    }
    
    //hapus grup
    public function hapus($id){
        if ($this->session->getValue('username') == TRUE AND $this->session->getValue('kode') == md5('sanca')) {
			if($this->session->getValue('grup')=="Admin"){
        if (isset($id)){
        $id=(int) base64_decode($id);
        $this->pbk->delgrup($id);
        $page=array(
            'konten'=>konten.'grup',
            'title' => 'Phone book'.TTL,
            'grup'=>$this->pbk->getgrup(),
            'refresh'=>$this->uri->baseUri.'grup',
            'pesan'=>'<div class="valid_box">Selamat anda telah berhasil Menghapus data</div>'
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'phonebook',
            'title' => 'Phone book'.TTL,
            'pbk'=> $this->pbk->getpbks(),
            'refresh'=>$this->uri->baseUri.'grup',
            'pesan'=>'<div class="warning_box">Tidak ada user yang terhapus</div>'
        );
            $this->output(TMP.'index',$page);
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan inputan.',
				);
				$this->output('errors/error',$page);
		}
        }else{
            $this->redirect('login');
        }
        
    }
}
