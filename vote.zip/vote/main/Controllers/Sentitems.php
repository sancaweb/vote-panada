<?php
namespace Controllers;
use Resources, Models;

class Sentitems extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->sms = new Models\Sms;
        $this->pbk= new Models\Phonebook;
        $this->session=new Resources\Session;
    }
    public function index($paging=1)
    {
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'sentitems' => $this->sms->sentitems($paging, $limit),
            'jumlah' => $this->sms->totsent(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'sentitems/index/%#%/',
		    'total' => $this->sms->totsent(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
            'konten'=>konten.'sentitems',
            'title' => 'vote'.TTL,
            'refresh'=>$this->uri->baseUri.'sentitems',
        );
        $this->output(TMP.'index',$page);
        }else{
            $this->redirect('login');
        }
    }
    
    //View detail sentitems
    public function view($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if(isset($id)){
        $id=(int)  base64_decode($id);
        $sentitemsnya=$this->sms->viewsentitems($id);
        //echo $sentitemsnya->DestinationNumber;exit;
        $page=array(
            'konten'=>konten.'viewsentitems',
            'title'=>'View Detail Sentitems'.TTL,
            'sentitems'=> $sentitemsnya,
            'pbk'=>$this->pbk->viewpbk2($sentitemsnya->DestinationNumber),
        );
        $this->output(TMP.'index',$page);
        }else{
            $this->index();
        }
        }else{
            $this->redirect('login');
        }
    }
    
    //hapus sentitems
    public function delete($id,$paging=1){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if (isset($id)){
                $id=(int) base64_decode($id);
                $this->sms->hapussentitems($id);
                $sentitemsnya=$this->sms->sentitems();
                //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'sentitems' => $this->sms->sentitems($paging, $limit),
            'jumlah' => $this->sms->totsent(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'sentitems/index/%#%/',
		    'total' => $this->sms->totsent(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
                'konten'=>konten.'sentitems',
                'title'=>'View Detail Sentitems'.TTL,
                'refresh'=>$this->uri->baseUri.'sentitems',
                'pesan'=>'<div class="valid_box">Selamat anda telah berhasil Menghapus data</div>'
            );
            $this->output(TMP.'index',$page);
                
            }else{
                $this->index($paging=1);
                
            }
        }else{
            $this->redirect('login');
        }
    }
}