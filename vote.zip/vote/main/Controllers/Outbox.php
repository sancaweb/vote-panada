<?php
namespace Controllers;
use Resources, Models;

class Outbox extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->sms = new Models\Sms;
        $this->pbk=new Models\Phonebook;
        $this->session=new Resources\Session;        
    }
    public function index($paging=1)
    {    if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
    //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            $outboxnya=$this->sms->outbox($paging, $limit);
            
            $page=array(
            'outbox' => $outboxnya,
            'jumlah' => $this->sms->totoutbox(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'outbox/index/%#%/',
		    'total' => $this->sms->totoutbox(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
            'konten'=>konten.'outbox',
            'title' => 'outbox'.TTL,
            'refresh'=>$this->uri->baseUri.'outbox',
        );
        $this->output(TMP.'index',$page);
    }else{
        $this->redirect('login');
    }
    }
    
    //view outbox
    public function view($id){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if (isset($id)){
        $id=(int)  base64_decode($id);
        $outboxnya=$this->sms->viewoutbox($id);
        $page=array(
            'konten'=>konten.'viewoutbox',
            'title'=>'View Detail outbox'.TTL,
            'outbox'=> $outboxnya,
            'pbk'=>$this->pbk->viewpbk2($outboxnya->DestinationNumber),
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'viewoutbox',
            'title'=>'View Detail outbox'.TTL,
        );
        $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    }
    
        //hapus outbox
        public function delete($id,$paging=1){
            if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
            if (isset($id)){
                $id=(int) base64_decode($id);
                $this->sms->hapusoutbox($id);
                $outboxnya=$this->sms->outbox();
                //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            $outboxnya=$this->sms->outbox($paging, $limit);
            
            $page=array(
            'outbox' => $outboxnya,
            'jumlah' => $this->sms->totoutbox(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'outbox/index/%#%/',
		    'total' => $this->sms->totoutbox(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
                'konten'=>konten.'outbox',
                'title'=>'View Detail outbox'.TTL,
                'refresh'=>$this->uri->baseUri.'outbox',
                'pesan'=>'<div class="valid_box">Selamat anda telah berhasil Menghapus data</div>'
            );
            $this->output(TMP.'index',$page);
                
            }else{
                $this->index($paging=1);
                
            }
            }else{
                $this->redirect('login');
            }
            
        }
}