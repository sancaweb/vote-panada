<?php
namespace Controllers;
use Resources, Models,Controllers;

class Home extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->sms = new Models\Sms;
        $this->controler=new Controllers\Sms;
        $this->graph = new Models\Graph;
        $this->session = new Resources\Session;
        $this->datavote=new Models\Datavote;
    }
    public function index()
    {    
		$pilihan=$this->graph->graph();
        $totalpilihan=$this->graph->allvote();
        $page=array(
            'column'=> 'column',
            'modal'=> 'modal/',
            'title'=> 'Vote'.TTL,
            'konten'=>konten.'chart',
            'chart'=>konten.'highchart',
            'pilihan'=>$pilihan,
             'pilihan2'=>$pilihan,                           
             'konten'=>konten.'chart',
             'setvote'=>$this->datavote->viewset(),
             'title'=> 'Vote'.TTL,
              'ref'=>'true',

        );        
            $this->output(TMP.'index',$page);
    }
    
    //test code
    public function test(){
        echo $this->session->getValue('username')."<br/>";
        echo $this->session->getValue('kode');

    }
}
