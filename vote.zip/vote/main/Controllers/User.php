<?php
namespace Controllers;
use Resources, Models,Controllers;

class User extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->user = new Models\User;
        $this->graph = new Models\Graph;
        $this->session = new Resources\Session;
        $this->request=new Resources\Request;
    }
    public function index($paging=1)
    {    if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'user' => $this->user->view($paging, $limit),
            'jumlah' => $this->user->total(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'user/index/%#%/',
		    'total' => $this->user->total(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
            
            'title'=> 'User Settings'.TTL,
            'konten'=>konten.'user',
            'grup'=>$this->user->viewgrup(),

        );        
            $this->output(TMP.'index',$page);
    }else{
        $this->redirect('login');
    }
    }
    
    //Edit user
    public function edit($id){
        if($this->session->getValue('username')==TRUE && $this->session->getValue('kode')==md5('sanca')) {
			if ($this->session->getValue('grup')=="Admin"){
        if (isset($id)){
        $id=(INT)  base64_decode($id);
        $username=$this->user->viewuser($id);
        
        $page=array(
            'konten'=>konten.'edituser',
            'title'=>'Edit User'.TTL,
            'username'=>$username,
            'grup'=>$this->user->viewgrup(),
        );
            $this->output(TMP.'index',$page);
        }else{
            $page=array(
                'konten'=>konten.'edituser',
                'title'=>'Edit User'.TTL,
                'grup'=>$this->user->viewgrup(),
                'pesan'=>'<div class="warning_box">Harap tekan tombol "Edit" terlebih dahulu ..!</div>'
        );
        $this->output(TMP.'index',$page);
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan editing.',
				);
				$this->output('errors/error',$page);
	}
        }else{
            $this->redirect('login');
        }
    }
    
    //proses edit
    public function prosesedit(){
        if($this->session->getValue('username')==TRUE && $this->session->getValue('kode')==md5('sanca')) {
        if ($this->session->getValue('grup')== "Admin"){
        if ($_POST){
        $kode=KODE;
        $id=$this->request->post('id');
        $username=$this->request->post('username',FILTER_SANITIZE_MAGIC_QUOTES);
        $oldpass=md5($this->request->post('passwordlama')).md5($kode);
        $password=$this->request->post('password');
        $password2=$this->request->post('password2');
        $grup=$this->request->post('grup');
        
        $cekpass=$this->user->cekpass($id,$oldpass);
        if ($cekpass){
            if (empty($username) || empty($password)){
                $page=array(
                    'konten'=>konten.'edituser',
                    'title'=>'Edit User'.TTL,
                    'username'=>$this->user->viewuser($id),
                    'grup'=>$this->user->viewgrup(),
                    'pesan'=>'<div class="warning_box">Isian username atau password anda masih kosong</div>'
                );
                $this->output(TMP.'index',$page);
                
            }else{
                if ($password==$password2){
                    $data=array(
                        'username'=>$username,
                        'password'=>md5($password).md5($kode),
                        'grup'=>$grup
                    );
                    $this->user->update($data, $id);
                    
                    $page=array(
                        'konten'=>konten.'edituser',
                        'title'=>'Edit User'.TTL,
                        'grup'=>$this->user->viewgrup(),
                        'pesan'=>'<div class="valid_box">Selamat anda berhasil edit data.</div>'
                );
                $this->output(TMP.'index',$page);
                
                }else{
                 echo 'Password tidak sesuai';   
                }
            }
        }else{
            $page=array(
                    'konten'=>konten.'edituser',
                    'title'=>'Edit User'.TTL,
                    'username'=>$this->user->viewuser($id),
                    'grup'=>$this->user->viewgrup(),
                    'pesan'=>'<div class="warning_box">Isikan Password lama anda dengan benar</div>'
                );
                $this->output(TMP.'index',$page);
        }
        }else{
            $this->index($paging=1);
        }
        
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan editing.',
				);
				$this->output('errors/error',$page);
	}
        }else{
            $this->redirect('login');
        }
    }
    
    //insert username
    public function input(){
        if($this->session->getValue('username')==TRUE && $this->session->getValue('kode')==md5('sanca')) {
			if ($this->session->getValue('grup') == "Admin"){
				$page=array(
            'konten'=>konten.'inputuser',
            'title'=>'Input User'.TTL,
            'grup'=>$this->user->viewgrup(),
        );
            $this->output(TMP.'index',$page);
			
			}else{
				$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan inputan.',
				);
				$this->output('errors/error',$page);
			}
        
        }else{
            $this->redirect('login');
        }
    }
    
    //proses input
    public function prosesinput(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if ($this->session->getValue('grup')=="Admin"){
        $kode=KODE;
        $username=$this->request->post('username',FILTER_SANITIZE_MAGIC_QUOTES);
        $password=$this->request->post('password');
        $password2=$this->request->post('password2');
        $grup=$this->request->post('grup');        
        $cekuser=$this->user->cekuser($username);
        
        
        if (empty($username) || empty($password) ){
            $page=array(
                    'konten'=>konten.'inputuser',
                    'title'=>'Input User'.TTL,
                    'grup'=>$this->user->viewgrup(),
                    'pesan'=>'<div class="warning_box">Username atau password harap di isi</div>'
                );
                    $this->output(TMP.'index',$page);
        }else{
            if ($password==$password2){
                if ($grup=='0'){
                    $page=array(
                        'konten'=>konten.'inputuser',
                        'title'=>'Input User'.TTL,
                        'grup'=>$this->user->viewgrup(),
                        'pesan'=>'<div class="warning_box">Silahkan pilih grup terlebih dahulu!</div>'
                );
                    $this->output(TMP.'index',$page);
                }else{
                    if ($cekuser){
                        $page=array(
                            'konten'=>konten.'inputuser',
                            'title'=>'Input User'.TTL,
                            'grup'=>$this->user->viewgrup(),
                            'pesan'=>'<div class="warning_box">Username Sudah terdaftar.</div>'
                        );
                    $this->output(TMP.'index',$page);
                    
                    }else{
                    
                    $data=array(
                        'username'=>$username,
                        'password'=>md5($password).md5($kode),
                        'grup'=>$grup,
                    );
                    
                    $this->user->input($data);
                    
                    $page=array(
                        'konten'=>konten.'inputuser',
                        'title'=>'Input User'.TTL,
                        'grup'=>$this->user->viewgrup(),
                        'pesan'=>'<div class="valid_box">Input User berhasil.</div>'
                );
                    $this->output(TMP.'index',$page);
                    }
                    
                }
                
            }else{
                $page=array(
                        'konten'=>konten.'inputuser',
                        'title'=>'Input User'.TTL,
                        'grup'=>$this->user->viewgrup(),
                        'pesan'=>'<div class="warning_box">Password tidak sesuai.</div>'
                );
                    $this->output(TMP.'index',$page);
                
            }
        }
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat melakukan inputan.',
				);
				$this->output('errors/error',$page);
	}
        }else{
            $this->redirect('login');
        }
    }
    
    //Delete User
    public function hapus($id,$paging=1){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        
        if ($this->session->getValue('grup')=="Admin"){
        if(isset($id)){
        $id=(int) base64_decode($id);
        $this->user->hapus($id);
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            
            $page=array(
            'user' => $this->user->view($paging, $limit),
            'jumlah' => $this->user->total(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'user/index/%#%/',
		    'total' => $this->user->total(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
                
            'konten'=>konten.'user',
            'title'=>'User'.TTL,
            'grup'=>$this->user->viewgrup(),
            'pesan'=>'<div class="valid_box">Delete User berhasil.</div>'
            );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'user',
            'title'=>'User'.TTL,
            'grup'=>$this->user->viewgrup(),
            'pesan'=>'<div class="warning_box">Harap tekan tombol delete terlebih dahulu..!!</div>'
            );
        $this->output(TMP.'index',$page);
        }
        
	}else{
		$page=array(
				'title'=>'Error',
				'message'=>'Anda Bukan Admin',
				'messagecon'=>'Hanya User yang berstatus "Admin" yang dapat menghapus data.',
				);
				$this->output('errors/error',$page);
		}
        }else{
            $this->redirect('login');
        }
    }
    
}
