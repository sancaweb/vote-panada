<?php
namespace Controllers;
use Resources,Models;

class Graph extends Resources\Controller {
    
    public function __construct(){
        
        parent::__construct();
        $this->graph = new Models\Graph;
        $this->sms= new Models\Sms;
        $this->datavote=new Models\Datavote;
    }
    public function index(){
        $pilihan=$this->graph->graph();
        $totalpilihan=$this->graph->allvote();
        $page=array(
            'pilihan'=>$pilihan,
            'pilihan2'=>$pilihan,
            'konten'=>konten.'chart',
            'totalpilihan'=>$totalpilihan,
            'title' => 'Hasil vote'.TTL,
            'chart'=>konten.'highchart'
        );
        $this->output(TMP.'index',$page);      
        
    }
    
    public function graph(){
        
        $datavote=$this->graph->graph();
        $hasilvote = array();
        $datacalon = array();
        $sanca='test';
        
        if ($datavote){
            foreach ($datavote as $datavote){
                    array_unshift($datacalon, $datavote->pilihan);
                    array_unshift($hasilvote, $datavote->vote);
            }
        }
        // membuat image dengan ukuran 600x200 px
        $graph = Resources\Import::vendor('jpgraph/src/jpgraph', 'Graph', array(700,300));
        $graph->SetScale("textlin");
        
        
        $bplot = Resources\Import::vendor('jpgraph/src/jpgraph_bar', 'BarPlot', array($hasilvote));                
        $lplot = Resources\Import::vendor('jpgraph/src/jpgraph_line', 'LinePlot', array($hasilvote));
        
        // membuat grafik nya  dan menambahkan beberapa properties     
        $graph->Add($bplot);
        $graph->add($lplot);
        $lplot->value->show();
        
        
        // menampilkan diagram batang untuk hasil vote dan berwarna hijau
        // pada diagram batang ditampilkan value data
        $bplot->SetFillColor("green");
        $bplot->value->show();
        $bplot->SetColor("black");
        $bplot->SetFillGradient("green","black",GRAD_WIDE_MIDVER);
        

        

        // mengatur margin image (left, right, top, bottom)
        $graph->img->SetMargin(80,110,50,40);

        // menampilkan title grafik dan nama masing-masing sumbu
        $graph->title->Set("GRAFIK HASIL PEMUNGUTAN SUARA");

        // menampilkan nama calon ke sumbu x diambil dari database
        $graph->xaxis->SetTickLabels($datacalon);

        // format font title grafik
        $graph->title->SetFont(FF_FONT1,FS_BOLD);
        //memunculkan frame
        $graph->SetFrame(true,'white');
        
                
        $graph->tabtitle->SetFont(FF_FONT1,FS_BOLD,13);
        // menampilkan efek shadow pada image
        $graph->SetShadow($aShowShadow=true,$aShadowWidth=10,$aShadowColor=array(102,102,102));

        // menampilkan image ke browser
        $graph->Stroke();
        
    }
}