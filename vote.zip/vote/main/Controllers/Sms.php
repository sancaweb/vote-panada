<?php
namespace Controllers;
use Resources, Models;

class Sms extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->sms = new Models\Sms;
        $this->graph = new Models\Graph;
        $this->datavote=new Models\Datavote;
        $this->pbk=new Models\Phonebook;
        $this->request=new Resources\Request;
        $this->session = new Resources\Session;
    }
    
    //sms form
    public function index(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        $page=array(
            'konten'=>konten.'sms',
            'title'=> 'Kirim SMS'.TTL,
            'phonebook'=>$this->pbk->getpbks(),
            'auto'=>'jsauto',
            'batassms'=>'yes'
            );
        
        $this->output(TMP.'index',$page);
        }else{
            $this->redirect('login');
        }
        
        
        
    }
    
    public function krmsms(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if ($_POST){
        $notlp=$this->request->post('notlp');
        $text=$this->request->post('text');
        //Proses merubah +62 ke 0
        if(!preg_match('/[^+0-9]/',trim($notlp))){
        // cek apakah no hp karakter 1-3 adalah +62
        if(substr(trim($notlp), 0, 3)=='+62'){
            $notlp=$notlp;
        }
        // cek apakah no hp karakter 1 adalah 0
        elseif(substr(trim($notlp), 0, 1)=='0'){
            $notlp = '+62'.substr(trim($notlp), 1);
        }
        }
        // end proses perubahan angka
        $data=array(
            'DestinationNumber' => $notlp,
            'TextDecoded' => $text,
            'CreatorID' => 'Gammu',
            'Class' => '-1',
            'SendingDateTime'=>date('Y-m-d H:i:s'),
        );
        $this->sms->inputOutbox($data);
        $page=array(
            'konten'=>'loading',
            'title'=> 'Loading ...'.TTL,
            'phonebook'=>$this->pbk->getpbks(),
            'pesan'=>'<div class="valid_box">Tunggu beberapa saat, SMS sedang dikirim</div>',
            'redirect'=>'sms'
            );
        $this->output(TMP.'index',$page);
        }else{
            $this->index();
        }
        }else{
            $this->redirect('login');
        }
    }
    //sms fom
    public function broadcast(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        $page=array(
            'konten'=>konten.'broadcast',
            'title'=> 'Broadcast'.TTL,
            'grup'=> $this->pbk->getgrup(),
            );
        
        $this->output(TMP.'index',$page);
        }else{
            $this->redirect('login');
        }
    }
    
    public function krmbroadcast(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        if($_POST){
        $text=$this->request->post('text');
        $grup=$this->request->post('grup');
        if ($grup=='0'){
            $notlp=$this->pbk->getpbks();
        }else{
            $notlp=$this->pbk->getpbk($grup);
        }
        
        foreach ($notlp as $notlp){
            //Proses merubah +62 ke 0
        if(!preg_match('/[^+0-9]/',trim($notlp->Number))){
        // cek apakah no hp karakter 1-3 adalah +62
        if(substr(trim($notlp->Number), 0, 3)=='+62'){
            $notlp=$notlp->Number;
        }
        // cek apakah no hp karakter 1 adalah 0
        elseif(substr(trim($notlp->Number), 0, 1)=='0'){
            $notlp = '+62'.substr(trim($notlp->Number), 1);
        }
        }
        // end proses perubahan angka
        $data=array(
            'DestinationNumber' => $notlp,
            'TextDecoded' => $text,
            'CreatorID' => 'Gammu',
            'Class' => '-1',
            'SendingDateTime'=>date('Y-m-d H:i:s'),
        );
        $this->sms->inputOutbox($data);
        
        }
        
        $page=array(
            'konten'=>'loading',
            'title'=> 'Loading ...'.TTL,
            'phonebook'=>$this->pbk->getpbks(),
            'pesan'=>'<div class="valid_box">Tunggu beberapa saat, SMS sedang dikirim</div>',
            'redirect'=>'sms/broadcast'
            );
        $this->output(TMP.'index',$page);
        }else{
            $this->index();
        }
        //disini
        }else{
            $this->redirect('login');
        }
    }
    
    public function vote(){
        if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
            $datasms=$this->sms->inboxVote();
        if ($datasms){
            $setvote=$this->datavote->viewset();
            if ($setvote->status=='1'){
            foreach($datasms as $datasms){
                    $id=$datasms->ID;
                    $nopengirim=$datasms->SenderNumber;
                    $sms=  strtoupper($datasms->TextDecoded);
                    $pecah=  explode('#',$sms);
                    $hitung=count($pecah);
                    if ($hitung=='2'){
                        $prefix=$pecah[0];
                        $pilihan=$pecah[1];
                    }else{
                        $prefix='';
                        $pilihan='';
                    }
                    
                    $pesanberhasil="Terimakasih ".$nopengirim.", Atas partisipasi voting anda";
                    $pesannopil="Maaf ".$nopengirim.", Pilihan yang anda pilih tidak ada";
                    $pesanformat="Maaf ".$nopengirim.", format yang anda masukan salah.";
                    $setvote=$this->datavote->viewset();
                
                if ($prefix==$setvote->format){
                    $datapilihan=$this->datavote->pilihan($pilihan);
                    if ($datapilihan){
                        $jmlvote=$this->datavote->jmlVote($pilihan)->vote;
                        $jumlahvote=$jmlvote+1;
                        
                        $data=array(
                            'Processed'=>'true',
                        );
                        $data2=array(
                          'vote'=>$jumlahvote  
                        );
                        $this->sms->updateInbox($data, $id);
                        $this->datavote->updatepoll($data2, $pilihan);
                        
                        $pesankirim=array(
                            'DestinationNumber' => $nopengirim,
                            'TextDecoded' => $pesanberhasil,
                            'CreatorID' => 'Gammu',
                             'Class' => '-1',
                            'SendingDateTime'=>date('Y-m-d H:i:s'),
                            
                        );
                        $this->sms->inputOutbox($pesankirim);
                        $pilihan=$this->graph->graph();
                        $totalpilihan=$this->graph->allvote();
                        $page=array(
                            'pilihan'=>$pilihan,
                            'pilihan2'=>$pilihan,                           
                            'konten'=>konten.'chart',
                            'setvote'=>$this->datavote->viewset(),
                            'title'=> 'Vote'.TTL,
                            'ref'=>'true',
                            'chart'=>konten.'highchart',
                            'pesan'=>$pesanberhasil,
                           // 'refresh'=>$this->uri->baseUri.'sms/vote',
            
                        );        
                            $this->output(TMP.'index',$page);
                    }else{
                        $data=array(
                            'Processed'=>'true',
                        );
                        $this->sms->updateInbox($data, $id);
                        $pesankirim=array(
                            'DestinationNumber' => $nopengirim,
                            'TextDecoded' => $pesannopil,
                            'CreatorID' => 'Gammu',
                             'Class' => '-1',
                            
                        );
                        $this->sms->inputOutbox($pesankirim);
                        $pilihan=$this->graph->graph();
                        $totalpilihan=$this->graph->allvote();
                        $page=array(
                            'pilihan'=>$pilihan,
                            'pilihan2'=>$pilihan,
                            'konten'=>konten.'chart',
                            'title'=> 'Vote'.TTL,
                            'ref'=>'true',
                            'pesan'=>$pesannopil,
                            'chart'=>konten.'highchart',
                            //'refresh'=>$this->uri->baseUri.'sms/vote',
                            'setvote'=>$this->datavote->viewset(),
            
                        );        
                            $this->output(TMP.'index',$page);
                    }
                }else{
                    $data=array(
                            'Processed'=>'true',
                        );
                        $this->sms->updateInbox($data, $id);
                        $pesankirim=array(
                            'DestinationNumber' => $nopengirim,
                            'TextDecoded' => $pesanformat,
                            'CreatorID' => 'Gammu',
                             'Class' => '-1',
                            
                        );
                        $this->sms->inputOutbox($pesankirim);
                        $pilihan=$this->graph->graph();
                        $totalpilihan=$this->graph->allvote();
                        $page=array(
                            'pilihan'=>$pilihan,
                            'pilihan2'=>$pilihan,
                            'konten'=>konten.'chart',
                            'title'=> 'Vote'.TTL,
                            'ref'=>'true',
                            'pesan'=>$pesanformat,
                            'chart'=>konten.'highchart',
                            //'refresh'=>$this->uri->baseUri.'sms/vote',
                            'setvote'=>$this->datavote->viewset(),
            
                        );        
                            $this->output(TMP.'index',$page);
                }
                
            }
             
        }else{
                        $pilihan=$this->graph->graph();
                        $totalpilihan=$this->graph->allvote();
                        $page=array(
                            'pilihan'=>$pilihan,
                            'pilihan2'=>$pilihan,
                            'konten'=>konten.'chart',
                            'title'=> 'Vote'.TTL,
                            'ref'=>'true',
                            'chart'=>konten.'highchart',
                           // 'refresh'=>$this->uri->baseUri.'sms/vote',
                            'setvote'=>$this->datavote->viewset(),
            
                        );        
                            $this->output(TMP.'index',$page);
        }
        }else{
            $pilihan=$this->graph->graph();
                        $totalpilihan=$this->graph->allvote();
                        $page=array(
                            'pilihan'=>$pilihan,
                            'pilihan2'=>$pilihan,
                            'konten'=>konten.'chart',
                            'title'=> 'Vote'.TTL,
                            'ref'=>'true',
                            'chart'=>konten.'highchart',
                           // 'refresh'=>$this->uri->baseUri.'sms/vote',
                            'setvote'=>$this->datavote->viewset(),
            
                        );        
                            $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    
    }
    
        //hasil vote
        public function hasilvote(){
            if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
            $pilihan=$this->graph->graph();
            $totalpilihan=$this->graph->allvote();
            $page=array(
                'pilihan'=>$pilihan,
                'pilihan2'=>$pilihan,
                'konten'=>konten.'chart',
                'title'=> 'Vote'.TTL,
                'ref'=>'true',
                'chart'=>konten.'highchart',
                'refresh'=>$this->uri->baseUri.'sms/hasilvote',

            );        
                $this->output(TMP.'index',$page);
            }else{
                $this->redirect('login');
            }
        
        }
}