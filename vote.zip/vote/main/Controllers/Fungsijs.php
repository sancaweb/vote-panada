<?php
namespace Controllers;
use Resources, Models;

class Fungsijs extends Resources\Controller
{    
    public function __construct(){
        parent::__construct();
        $this->request = new Resources\Request;
        $this->session = new Resources\Session;
        $this->pbk=new Models\Phonebook;
     
        }
        
    public function index()
    {    
        $this->redirect('home');
    }
    
    //pengambilan data notlp untuk ajax
    public function notlp(){
        $name=$this->request->post('nama');
        $notlp=$this->pbk->viewpbk3($name);
        
        if ($notlp){
            foreach($notlp as $notlp){
                //echo $notlp;
                echo substr_replace($notlp,'0',0,3);
            }
        }
    }
}