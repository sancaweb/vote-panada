<?php
namespace Controllers;
use Resources, Models;

class Inbox extends Resources\Controller
{    
    public function __construct(){
        
        parent::__construct();
        $this->sms = new Models\Sms;
        $this->pbk=new Models\Phonebook;
        $this->session=new Resources\Session();
    }
    public function index($paging=1)
    {    if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
        //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            $inboxnya=$this->sms->inbox($paging, $limit);
            $page=array(
            'inbox' => $inboxnya,
            'jumlah' => $this->sms->totinbox(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'inbox/index/%#%/',
		    'total' => $this->sms->totinbox(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
            'konten'=>konten.'inbox',
            'title' => 'Inbox'.TTL,
            'refresh'=>$this->uri->baseUri.'inbox'
        );
        $this->output(TMP.'index',$page);
    }else{
        $this->redirect('login');
    }
    }
    
    //view inbox
    public function view($id){
        if ($this->session->getValue('username') == TRUE AND $this->session->getValue('kode') == md5('sanca')) {
        if (isset($id)){
        $id=(int)  base64_decode($id);
        $inboxnya=$this->sms->viewinbox($id);
        $page=array(
            'konten'=>konten.'viewinbox',
            'title'=>'View Detail Inbox'.TTL,
            'inbox'=> $inboxnya,
            'pbk'=>$this->pbk->viewpbk2($inboxnya->SenderNumber),
        );
        $this->output(TMP.'index',$page);
        }else{
            $page=array(
            'konten'=>konten.'viewinbox',
            'title'=>'View Detail Inbox'.TTL,
        );
        $this->output(TMP.'index',$page);
        }
        }else{
            $this->redirect('login');
        }
    } 
    
    
        //hapus inbox
        public function delete($id,$paging=1){
            if ($this->session->getValue('username') == TRUE AND $this->session->getValue('kode') == md5('sanca')) {
            if (isset($id)){
                $id=(int) base64_decode($id);
                $this->sms->hapusinbox($id);
                $inboxnya=$this->sms->inbox();
                //pagination
            $this->pagination = new Resources\Pagination;
            $paging = (int) $paging;
            $limit = 10;
            $inboxnya=$this->sms->inbox($paging, $limit);
            $page=array(
            'inbox' => $inboxnya,
            'jumlah' => $this->sms->totinbox(),
            
            'page_links' => $this->pagination
	    ->setOption(
		array(
		    'limit' => $limit,
		    'base' => $this->uri->baseUri.'inbox/index/%#%/',
		    'total' => $this->sms->totinbox(),
		    'current' => $paging,
		)
	    )
	    ->getUrl(),
            'no' => ($paging * $this->pagination->limit) - $this->pagination->limit,
            //end pagination
                'konten'=>konten.'inbox',
                'title'=>'View Detail Inbox'.TTL,
                'refresh'=>$this->uri->baseUri.'inbox',
                'inbox'=>$inboxnya,
                'pesan'=>'<div class="valid_box">Selamat anda telah berhasil Menghapus data</div>'
            );
            $this->output(TMP.'index',$page);
                
            }else{
                $this->index($paging=1);
                
            }
            }else{
                $this->redirect('login');
            }
            
        }
        
        //balas sms
        public function balas($id){
            if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
            if (isset($id)){
        $id=(int)  base64_decode($id);
        $inboxnya=$this->sms->viewinbox($id);
        $page=array(
            'konten'=>konten.'sms',
            'title'=>'Balas SMS'.TTL,
            'inbox'=> $inboxnya,
            'pbk'=>$this->pbk->viewpbk2($inboxnya->SenderNumber),
            'batassms'=>'yes',
        );
        $this->output(TMP.'index',$page);
        }else{
        $page=array(
                'konten'=>konten.'sms',
                'title'=>'Kirim sms'.TTL,
                'auto'=>'jsauto',
                'batassms'=>'yes',
                'phonebook'=>$this->pbk->getpbks(),
        );
        $this->output(TMP.'index',$page);
        }
            }else{
                $this->redirect('login');
            }
            
        }
        
}