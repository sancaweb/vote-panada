<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<div class="row">
        <div class="span4">
            <?php $this->output(TMP."column/column1");?>
        </div>
        <div class="span4">
            <?php $this->output(TMP."column/column2");?>
        </div>
        <div class="span4">
            <?php $this->output(TMP."column/column3");?>
        </div>
      </div>