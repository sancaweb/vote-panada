<center>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
        
    <img src="<?php echo $this->uri->baseUri;?>style/img/loading.gif" /></center>
<meta http-equiv="refresh" content="2; URL=<?php echo $this->uri->baseUri.$redirect;?>">
