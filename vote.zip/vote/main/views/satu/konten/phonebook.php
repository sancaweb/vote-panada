<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Phonebook</h2></legend><br/>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?></center>
<table id="gradient-style" summary="Meeting Results">
    <thead>
    	<tr>
            <th scope="col">No</th>
            <th scope="col">Nama</th>
            <th scope="col">No Telpon</th>
            <th scope="col">Grup</th>
            <th scope="col">View</th>
            <th scope="col">Edit</th>
            <th scope="col">Hapus</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if($pbk){
        $i=$no;
            foreach($pbk as $pbk){
                
                $i++;
                ?>
        <tr>
            <td><?php echo $i;?></td>
            <td><?php echo $pbk->Name;?></td>
            <td><?php echo substr_replace($pbk->Number,'0',0,3);?></td>
            <td><?php echo $pbk->grup;?></td>
            <td><a href="<?php echo $this->uri->baseUri;?>phonebook/viewpbk/<?php echo base64_encode($pbk->ID);?>" ><img src="<?php echo $this->uri->baseUri;?>aset/img/view.png" /></a></td>
            <?php if ($this->session->getValue('grup')=="Admin"){?>
            <td><a href="<?php echo $this->uri->baseUri;?>phonebook/edit/<?php echo base64_encode($pbk->ID);?>"><img src="<?php echo $this->uri->baseUri;?>aset/img/edit.png" /></a></td>
            <td><a href="<?php echo $this->uri->baseUri;?>phonebook/hapus/1/<?php echo base64_encode($pbk->ID);?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini...?')"><img src="<?php echo $this->uri->baseUri;?>aset/img/hapus.png" /></a></td>
        <?php }else{?>
			<td><a href="<?php echo $this->uri->baseUri;?>phonebook/edit/<?php echo base64_encode($pbk->ID);?>"><img src="<?php echo $this->uri->baseUri;?>aset/img/edit.png" /></a></td>
            <td>Khusus Admin</td>
            <?php }?>
        </tr>
        
        <?php
            }
        }
?>
    	
    </tbody>
    <tfoot>
    	<tr>
            <td colspan="4">
        	<?php if ($page_links): ?>
            
                <?php foreach ($page_links as $paging): ?>
                    <?php echo $paging; ?>&nbsp;|&nbsp
                <?php endforeach; ?>
            
        <?php endif; ?>
            </td>
            <td align="right" colspan="3"><b>Total jumlah Phonebook ada:&nbsp;<?php echo $jumlah; ?>&nbsp;Phonebook</b><br/>            
            </td>
        </tr>
        <tr>
            <td colspan="5">&nbsp;</td>
            <td align="right" colspan="2">
            <?php if ($this->session->getValue('grup')=="Admin"){?>
                <a href="<?php echo $this->uri->baseUri;?>phonebook/emptypbk"><img src="<?php echo $this->uri->baseUri;?>aset/img/clean.png" width="50" title="Silahkan Click untuk empty data"onclick="return confirm('Apakah anda yakin ingin menghapus seluruh data phonebook...?')"/>Hapus Semua Phonebook</a>
            <?php }?>
            </td>
        </tr>
    </tfoot>
</table>
