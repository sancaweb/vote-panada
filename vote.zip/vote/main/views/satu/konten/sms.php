<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend>
        <?php if (isset($inbox)){
                    if ($inbox==""){
                        echo '<h2>Kirim SMS</h2>';                        
                        }else{
                            echo '<h2>Balas SMS</h2>';
                            
                            }                            
                            }else{
                                echo '<h2>Kirim SMS</h2>';                                
                                }?>
        </legend>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?></center>
      <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>sms/krmsms" name="formsms">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Nama</label>
            <div class="controls">
                <?php if (isset($pbk)){
                    if ($pbk==""){
                        ?>
                    <input type="text" class="input-xlarge" id="auto" readonly="" name="nama" title="Nomer belum tersimpan"  Value="Nomer belum tersimpan">                        
                         <?php
                        }else{
                            ?>
                        <input type="text" name="nama" class="input-xxlarge" id="auto" readonly="readonly" Value="<?php echo $pbk->Name;?>"/>
                        <?php                           
                            }                            
                            }else{
                                echo '<input type="text" name="nama" class="input-xlarge" id="auto" >';                                
                                }?>
              
            </div>
          </div>
            <div class="control-group">
            <label class="control-label" for="input01">No telpon</label>
            <div class="controls">
                <?php if (isset($inbox)){
                    if ($inbox==""){
                        echo '<input type="text" class="input-xlarge" id="notlp" name="notlp">';                        
                        }else{
                            echo '<input type="text" class="input-xlarge" id="notlp" name="notlp" readonly="" value="'.substr_replace($inbox->SenderNumber,'0',0,3).'">';
                            
                            }                            
                            }else{
                                echo '<input type="text" class="input-xlarge" id="notlp" name="notlp">';                                
                                }?>
              
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="textarea">Isi SMS</label>
            <div class="controls">
              <textarea class="input-xlarge" id="textarea" rows="3" cols="30" name="text" onKeyUp="count()"></textarea><br/>
              <input type="text" readonly name="counter" size="3" class="input-small"/>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary">Kirim SMS</button>
            <INPUT TYPE="BUTTON" class="btn btn-danger" VALUE="Back" ONCLICK="history.go(-1)">
          </div>
        </fieldset>
      </form>