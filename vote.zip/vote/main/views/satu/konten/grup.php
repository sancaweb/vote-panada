<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Phonebook Group</h2></legend><br/>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>

      <form class="form-horizontal" method="post" <?php if (isset($name)){
                                                          echo 'action="'.$this->uri->baseUri.'grup/prosesedit"';
                                                        }else{
                                                            echo 'action="'.$this->uri->baseUri.'grup/input"';                                                        }
                                                    ?>
                                                    >
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">grup</label>
            <div class="controls">
            
                <?php if (isset($name)){
                    echo '<input type="text" class="input-xlarge" id="input01" name="nama" title="Silahkan edit" value="'.$name->Name.'">';
                    echo '<input type="hidden" class="input-xlarge" id="input01" name="id" title="Silahkan edit" value="'.$name->ID.'">';
                    echo '<input type="hidden" class="input-xlarge" id="input01" name="namaawal" title="Silahkan edit" value="'.$name->Name.'">';
                }else{
                    echo '<input type="text" class="input-xlarge" id="input01" name="nama" title="Isikan untuk add grup phonebook">';
                }
                ?>
              
            </div>
          </div>
          <div class="form-actions">
              <?php if (isset($name)){
                  echo '<button type="submit" class="btn btn-primary">Save</button>';
              }else{
                  echo '<button type="submit" class="btn btn-primary">Input</button>';
              }
                ?>
            
          </div>
        </fieldset>
      </form>

    <table id="gradient-style" summary="Meeting Results">
    <thead>
    	<tr>
            <th scope="col">No</th>
            <th scope="col">Nama Grup</th>
            <th scope="col">Edit&nbsp;|&nbsp;Hapus</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if($grup){
        $no=0;
            foreach($grup as $grup){
                
                $no++;
                ?>
        <tr>
            <td><?php echo $no;?></td>
            <td><?php echo $grup->Name;?></td>
            <td>
            <?php if($this->session->getValue('grup')=="Admin"){?>
            <a href="<?php echo $this->uri->baseUri;?>grup/edit/<?php echo base64_encode($grup->ID);?>" ><img src="<?php echo $this->uri->baseUri;?>aset/img/edit.png" /></a>&nbsp;|&nbsp;
            <a href="<?php echo $this->uri->baseUri;?>grup/hapus/<?php echo base64_encode($grup->ID);?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini...?')"><img src="<?php echo $this->uri->baseUri;?>aset/img/hapus.png" /></a>
                <?php }else{?>
                Khusus Admin &nbsp;|&nbsp; Khusus Admin  
                <?php }?>
            </td>
        </tr>
        
        <?php
            }
        }
?>
    	
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="4">Hanya user yang berstatus "Admin" yang dapat melakukan pengaturan Grup Phonebook.</td>
        </tr>
    </tfoot>
    </table>
