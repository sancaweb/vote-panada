<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>View detail Sentitems</h2></legend></center>
    <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>phonebook/input">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Nama</label>
            <div class="controls">
                <?php if (isset($pbk)){
                    if ($pbk==""){
                        ?>
                        <input type="text" name="nama" class="input-xxlarge" id="input01" readonly="readonly" Value='Nomer belum tersimpan, silahkan klik tombol " Simpan Nomer "'/>
                         <?php
                         $status="0";
                        }else{
                            ?>
                        <input type="text" name="nama" class="input-xxlarge" id="input01" readonly="readonly" Value="<?php echo $pbk->Name;?>"/>
                        <?php                           
                            }                            
                            }else{
                                echo "Nomer belum tersimpan";                                
                                }?>
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Nomer Telpon Penerima</label>
            <div class="controls">
              <input type="text" name="notlp" class="input-xlarge" id="input01" readonly="readonly" value="<?php if (isset($sentitems)){ if ($sentitems==""){echo "Data kosong";}else{echo substr_replace($sentitems->DestinationNumber,'0',0,3);}}else{echo "Data Kosong";}?>" />
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Text</label>
            <div class="controls">
              <textarea rows="3" readonly="readonly"><?php if (isset($sentitems)){ if ($sentitems==""){echo "Data kosong";}else{echo $sentitems->TextDecoded;}}else{echo "Data Kosong";}?></textarea>
            </div>
          </div>
          <div class="form-actions">
              <?php if (isset($status)){
                  if ($status=="0"){ ?>
                <button type="submit" class="btn btn-primary" onclick="return confirm('Simpan nomer..?')">Simpan Nomer</button>  
              <?php }}
              ?>
            <input type="button" class="btn btn-danger" value="Kembali" onclick="location.href='<?php echo $this->uri->baseUri;?>sentitems'" />
            
          </div>
        </fieldset>
    </form>