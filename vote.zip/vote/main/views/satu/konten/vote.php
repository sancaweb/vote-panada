<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Vote Setting</h2></legend>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>
    <legend><h3>Add/Edit pilihan</h3></legend>
      <form class="form-horizontal" method="post" <?php if (isset($pilihannya)){
          echo 'action="'.$this->uri->baseUri.'setvote/prosesedit"';
      }else{
          echo 'action="'.$this->uri->baseUri.'setvote/input"';
      }
        ?>>
        <fieldset>
            
          <div class="control-group">
            <label class="control-label" for="input01">Pilihan</label>
            <div class="controls">
                <?php
                if (isset($pilihannya)){
                    echo '<input type="text" class="input-xlarge" id="input01" name="nama" value="'.$pilihannya->pilihan.'">';
                    echo '<input type="hidden" class="input-xlarge" id="input01" name="id" value="'.$pilihannya->id.'">';
                    
                }else{
                    echo '<input type="text" class="input-xlarge" id="input01" name="nama" ">';
                }
                ?>
              
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Keterangan</label>
            <div class="controls">
                <?php if (isset($pilihannya)){
                    echo '<input type="text" class="input-xlarge" id="input01" name="keterangan" value="'.$pilihannya->keterangan.'">';
                    
                }else{
                    echo '<input type="text" class="input-xlarge" id="input01" name="keterangan" ">';
                }
                ?>
              
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Nomor Urut</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" name="norut" <?php if (isset($pilihannya)){echo 'value="'.$pilihannya->urut.'"';}else {?> value="Harap dilihat nomer urut yang telah masuk." onfocus="this.value=''" <?php } ?> title="Sebelum input harap check nomer urut yang sudah ada">
            </div>
          </div>
          
          <div class="form-actions">
            <button type="submit" class="btn btn-primary" onclick="return confirm('Apakah anda yakin sudah memasukan data dengan benar...?')">Save</button>
            <input type="button" class="btn btn-danger" value="Cancel" onclick="location.href='<?php echo $this->uri->baseUri;?>setvote'" />
          </div>
        </fieldset>
      </form>
    
    
    <legend><h3>Vote setting</h3></legend>    
    <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>setvote/updateset">
        <fieldset>
            <div class="control-group">
            <label class="control-label" for="input01">Judul Vote</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" name="judul"  title="harap atur format sms tanpa spasi" value="<?php echo $setvote->judul;?>">
            </div>
          </div>
            <div class="control-group">
            <label class="control-label" for="input01">Format</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" name="format"  title="harap atur format sms tanpa spasi" value="<?php echo $setvote->format;?>">
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="select01">Warna</label>
            <div class="controls">
              <select id="select01" name="warna">
                  <option value="0">---= Silahkan pilih warna =---</option>
                  
                  <?php if (isset($warna)){
                      foreach ($warna as $warna){
                          ?>
                  
                  <option <?php if (isset($setvote)){
                      if ($setvote->warna==$warna->warna){
                          echo "selected";
                      }
                      
                          }
                        ?>><?php echo $warna->warna;?></option>
                  
                  <?php
                      }
                  }
                    ?>
              </select>
            </div>
          </div>
            
          <div class="control-group">
            <label class="control-label">Vote Status</label>
            <div class="controls">
                <?php if ($setvote->status=='1'){
                    ?>
                <label class="radio">
                <input type="radio" name="stt"  value="1" checked><label><img src="<?php echo $this->uri->baseUri;?>aset/img/acc.png" height="20" width="20">&nbsp;Aktif</label>
              </label>
              <label class="radio">
                <input type="radio" name="stt" value="0" ><label><img src="<?php echo $this->uri->baseUri;?>aset/img/tolak.png" height="20" width="20">&nbsp;Non Aktif</label>
              </label>
                
                <?php
                }else{
                    ?>
                <label class="radio">
                <input type="radio" name="stt"  value="1"><label><img src="<?php echo $this->uri->baseUri;?>aset/img/acc.png" height="20" width="20">&nbsp;Aktif</label>
              </label>
              <label class="radio">
                <input type="radio" name="stt" value="0" checked><label><img src="<?php echo $this->uri->baseUri;?>aset/img/tolak.png" height="20" width="20">&nbsp;Non Aktif</label>
              </label>
                <?php
                }
                ?>
              
            </div>
            </div>
            
          <div class="form-actions">
            <button type="submit" class="btn btn-primary" onclick="return confirm('Apakah anda yakin ingin mengedit data?')">Update</button>
            <input type="button" class="btn btn-danger" value="Cancel" onclick="location.href='<?php echo $this->uri->baseUri;?>setvote'" />
          </div>
            
        </fieldset>
      </form>
        <table id="gradient-style" summary="Meeting Results">
    <thead>
    	<tr>
            <th scope="col">No Urut</th>
            <th scope="col">Prefix</th>            
            <th scope="col">Pilihan</th>
            <th scope="col">Keterangan</th>
            <th scope="col">Warna Vote</th>
            <th scope="col">Edit&nbsp;|&nbsp;Hapus</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if($pilihan){
            foreach($pilihan as $pilihan){
                ?>
        <tr>
            <td><?php echo $pilihan->urut;?></td>
            <td><?php echo $setvote->format;?></td>            
            <td><?php echo $pilihan->pilihan;?></td>
            <td><?php echo $pilihan->keterangan;?></td>
            <td><?php echo $setvote->warna;?></td>
            <td>
            <?php if($this->session->getValue('grup')=="Admin"){?>
            <a href="<?php echo $this->uri->baseUri;?>setvote/edit/<?php echo base64_encode($pilihan->id);?>" ><img src="<?php echo $this->uri->baseUri;?>aset/img/edit.png" /></a>&nbsp;|&nbsp;
                <a href="<?php echo $this->uri->baseUri;?>setvote/delete/<?php echo base64_encode($pilihan->id);?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini...?')"><img src="<?php echo $this->uri->baseUri;?>aset/img/hapus.png" /></a>
                <?php }else{
					echo 'Khusus Admin&nbsp;|&nbsp;Khusus Admin';
                }
                ?>
                </td>
        </tr>
        
                    <?php
                        }
                    }
                    ?>    	
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="4"></td>
        </tr>
    </tfoot>
    </table>
    
