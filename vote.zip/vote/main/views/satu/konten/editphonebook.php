<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Edit Phonebook</h2></legend>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>

      <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>phonebook/prosesedit">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Nama</label>
            <div class="controls">
                <input type="hidden" class="input-xlarge" id="input01" name="id" value="<?php if (isset($pbk)){echo $pbk->ID;}else{echo "Data Kosong";}?>">
              <input type="text" class="input-xlarge" id="input01" name="nama" value="<?php if (isset($pbk)){echo $pbk->Name;}else{echo "Data Kosong";}?>">
            </div>
          </div>
            <div class="control-group">
            <label class="control-label" for="input01">No.tlp</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" name="notlp" value="<?php if (isset($pbk)){echo substr_replace($pbk->Number,'0',0,3);}else{echo "Data Kosong";}?>">
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="select01">Grup</label>
            <div class="controls">
              <select id="select01" name="grup">
                  <option value="0">---= Silahkan pilih grup =---</option>
                  
                  <?php if (isset($grup)){
                      foreach ($grup as $grup){
                          ?>
                  
                  <option <?php if ($pbk->grup == $grup->Name){echo 'selected=""';}?>><?php echo $grup->Name;?></option>
                  
                  <?php
                      }
                  }
                    ?>
              </select>
            </div>
          </div>
          <input type="hidden" value="<?php echo $this->session->getValue('username')?>" name="operator"></input>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary" onclick="return confirm('Apakah anda yakin ingin mengedit data ini...? Pastikan data yang anda masukan sudah benar...!')">Save changes</button>
            <input type="button" class="btn btn-danger" value="Kembali" onclick="location.href='<?php echo $this->uri->baseUri;?>phonebook'" />
            
          </div>
        </fieldset>
      </form>
