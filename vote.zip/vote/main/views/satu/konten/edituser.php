<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Edit User</h2></legend><br/>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>
      <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>user/prosesedit">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Username</label>
            <div class="controls">
                <input type="text" class="input-xlarge" id="input01" name="username" title="Silahkan edit" value="<?php if (isset($username)){echo $username->username;}?>">
                <input type="hidden" class="input-xlarge" id="input01" name="id" title="Silahkan edit" value="<?php if (isset($username)){echo $username->id;}?>">              
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Password Lama</label>
            <div class="controls">
                    <input type="text" class="input-xlarge" id="input01" name="passwordlama" title="Isikan Password anda">
                
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Password Baru</label>
            <div class="controls">
                    <input type="text" class="input-xlarge" id="input01" name="password" title="Isikan Password anda yang baru">
                
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Ulangi Password Baru</label>
            <div class="controls">
                    <input type="text" class="input-xlarge" id="input01" name="password2" title="Isikan Password anda yang baru">
                
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="select01">Grup</label>
            <div class="controls">
              <select id="select01" name="grup">
                  <option value="0">---= Silahkan pilih grup =---</option>
                  <?php if ($grup){
                      foreach ($grup as $grup){
                          ?>
                  <option <?php if (isset($username)){if ($username->grup==$grup->grup){echo 'selected=""';}}?>value="<?php echo $grup->grup;?>"><?php echo $grup->grup;?></option>
                  
                  <?php
                      }
                  }
                    ?>
              </select>
            </div>
          </div>
            
          <div class="form-actions">
              <?php if (isset($username)){
                  echo '<button type="submit" class="btn btn-primary">Save</button>';
              }
            ?>
              
              <input type="button" class="btn btn-danger" value="Kembali" onclick="location.href='<?php echo $this->uri->baseUri;?>user'" />
          </div>
        </fieldset>
      </form>