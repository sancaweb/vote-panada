<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<script src="<?php echo $this->uri->baseUri;?>style/js/chart/jquery.min.js"></script>
		<script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        var 
        categories = [
            <?php 
            $totalpilihan=$this->graph->allvote();
            if (isset($pilihan)){
                foreach ($pilihan as $pilihan){
                    $pilihannya=$pilihan->pilihan;
                         $voted=$this->datavote->jmlvote($pilihannya)->vote;
                         $persen=$voted/$totalpilihan*100;
                    ?>
                '<?php echo $pilihan->pilihan;?>,<br/>(<?php echo round($persen,2);?>%)', 
                <?php
                }
            }
            ?>
                        ],
             data = [
                 <?php 
                 
                 if (isset($pilihan2)){
                     foreach ($pilihan2 as $pilihan2){
                         
                         ?>
                         {
                            y: <?php echo $pilihan2->vote; ?>,
                            color: '<?php echo $setvote->warna;?>'
                        },
                         <?php
                     }
                 }
                         ?>
                  ];
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'container',
                type: 'column',
                margin: [ 50, 50, 100, 80]
            },
            title: {
                text: 'HASIL PEROLEHAN SUARA<br/>"<?php echo $setvote->judul;?>"'
            },
            xAxis: {
                categories: categories,
                labels: {
                    rotation: -45,
                    align: 'right',
                    style: {
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah Pemilih'
                }
            },
            legend: {
                enabled: false
            },
            tooltip: {
                formatter: function() {
                    return '<b>'+ this.x +'</b><br/>'+
                        'Jumlah pemilih: '+ Highcharts.numberFormat(this.y, 0) +
                        ' Orang, Sampai saat ini.';
                }
            },
                series: [{
                name: 'Hasil',
                data:data,
                dataLabels: {
                    enabled: true,
                    color: 'white',
                    x: -3,
                    y: -10,
                    formatter: function() {
                      return '<b>'+Highcharts.numberFormat(this.y, 0) + '</b>'+'Pemilih';
                    },
                    style: {
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            }]
        });
    });
    
});
		</script>