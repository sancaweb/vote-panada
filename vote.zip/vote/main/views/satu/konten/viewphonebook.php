<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>View detail Phonebook</h2></legend>
      
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Nama</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" readonly="readonly" value="<?php if (isset($pbk)){ if ($pbk==""){echo "Data kosong";}else{echo $pbk->Name;}}else{echo "Data Kosong";}?>" />
            </div>
          </div>
            <div class="control-group">
            <label class="control-label" for="input01">No.tlp</label>
            <div class="controls">
              <input type="text" class="input-xlarge" id="input01" readonly="readonly" value="<?php if (isset($pbk)){ if ($pbk==""){echo "Data kosong";}else{echo substr_replace($pbk->Number,'0',0,3);}}else{echo "Data Kosong";}?>" />
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="select01">Grup</label>
            <div class="controls">
              <input type="text" class="input-large" id="input01" readonly="readonly" value="<?php if (isset($pbk)){ if ($pbk==""){echo "Data kosong";}else{echo $pbk->grup;}}else{echo "Data Kosong";}?>" />
            </div>
          </div>
          <div class="form-actions">
            
            <input type="button" class="btn btn-danger" value="Kembali" onclick="location.href='<?php echo $this->uri->baseUri;?>phonebook'" />
            
          </div>
        </fieldset>
    </center>
