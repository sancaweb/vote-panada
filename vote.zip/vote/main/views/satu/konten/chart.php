
<script src="<?php echo $this->uri->baseUri;?>style/js/chart/highcharts.js"></script>
<script src="<?php echo $this->uri->baseUri;?>style/js/chart/modules/exporting.js"></script>
<script type="text/javascript" src="<?php echo $this->uri->baseUri;?>style/js/chart/themes/gray.js"></script>

<div id="container" style="min-width: 400px; height: 400px; margin: 0 auto"></div>
        