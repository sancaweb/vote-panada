<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>User Settings</h2></legend><br/>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>
    <table id="gradient-style" summary="Meeting Results">
    <thead>
    	<tr>
            <th scope="col">No</th>
            <th scope="col">Username</th>
            <th scope="col">Grup User</th>
            <th scope="col">Edit&nbsp;|&nbsp;Hapus</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if($user){
        $no=0;
            foreach($user as $user){
                
                $no++;
                ?>
        <tr>
            <td><?php echo $no;?></td>
            <td><?php echo $user->username;?></td>
            <td><?php echo $user->grup;?></td>
            <?php if ($this->session->getValue('grup')=="Admin"){?>
            <td><a href="<?php echo $this->uri->baseUri;?>user/edit/<?php echo base64_encode($user->id);?>" ><img src="<?php echo $this->uri->baseUri;?>aset/img/edit.png" /></a>&nbsp;|&nbsp;
                <a href="<?php echo $this->uri->baseUri;?>user/hapus/<?php echo base64_encode($user->id);?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini...?')"><img src="<?php echo $this->uri->baseUri;?>aset/img/hapus.png" /></a></td>
        <?php }else{?>
        <td>Khusus Admin</td>
        <?php }?>
        </tr>
        
        <?php
            }
        }
?>
    	
    </tbody>
    
    <tfoot>
    	<tr>
            <td colspan="3">
        	<?php if ($page_links): ?>
            
                <?php foreach ($page_links as $paging): ?>
                    <?php echo $paging; ?>&nbsp;|&nbsp
                <?php endforeach; ?>
            
        <?php endif; ?>
            </td>
            <td align="right" colspan="2"><b>Total jumlah User ada:&nbsp;<?php echo $jumlah; ?>&nbsp;User</b></td>
        </tr>
    </tfoot>
    </table>
