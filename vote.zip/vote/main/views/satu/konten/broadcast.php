<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Kirim SMS Broadcast</h2></legend></center>
      <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>sms/krmbroadcast">
        <fieldset>
            
            <div class="control-group">
            <label class="control-label" for="select01">Grup</label>
            <div class="controls">
              <select id="select01" name="grup">
                  <option value="0">---= Silahkan pilih grup =---</option>
                  <?php if ($grup){
                      foreach ($grup as $grup){
                          ?>
                  <option value="<?php echo $grup->Name;?>"><?php echo $grup->Name;?></option>
                  
                  <?php
                      }
                  }
                    ?>
              </select>
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="textarea">Isi SMS</label>
            <div class="controls">
              <textarea class="input-xlarge" id="textarea" rows="3" name="text"></textarea>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary">Kirim Broadcast</button>            
          </div>
        </fieldset>
      </form>