<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>SentItems</h2></legend></center>
<table id="gradient-style" summary="Meeting Results">
    <thead>
    	<tr>
            <th scope="col">No</th>
            <th scope="col">Penerima</th>
            <th scope="col">Text</th>
            <th scope="col">Date</th>
            <th scope="col">View</th>
            <th scope="col">Hapus</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if($sentitems){
        $no=0;
            foreach($sentitems as $sentitems){
                
                $no++;
                ?>
        <tr>
            <td><?php echo $no;?></td>
            <td><?php
                    $nama=$this->pbk->viewpbk2($sentitems->DestinationNumber);
                    
                    if ($nama){
                        echo $nama->Name;
                    }else{
                        echo '<font color="red">'.substr_replace($sentitems->DestinationNumber,'0',0,3).'&nbsp;(Nomer belum tersimpan)</font>';
                    }?></td>
            <td><?php echo $sentitems->TextDecoded;?></td>
            <td><?php echo $sentitems->SendingDateTime;?></td>
            <td><a href="<?php echo $this->uri->baseUri;?>sentitems/view/<?php  echo base64_encode($sentitems->ID);?>" ><img src="<?php echo $this->uri->baseUri;?>aset/img/view.png" /></a></td>            
            <td><a href="<?php echo $this->uri->baseUri;?>sentitems/delete/<?php echo base64_encode($sentitems->ID);?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini...?')"><img src="<?php echo $this->uri->baseUri;?>aset/img/hapus.png" /></a></td>
        </tr>
        
        <?php
            }
        }
?>
    	
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="4">
                    <?php if ($page_links): ?>
            
                <?php foreach ($page_links as $paging): ?>
                    <?php echo $paging; ?>&nbsp;|&nbsp
                <?php endforeach; ?>
            
        <?php endif; ?>
                </td>
                <td alig="right" colspan="3"><b>Total jumlah Sentitems ada:&nbsp;<?php echo $jumlah; ?>&nbsp;Pesan</b></td>
        </tr>
    </tfoot>
</table>