<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<center><legend><h2>Input User</h2></legend><br/>
    <?php if (isset($pesan)){
            echo $pesan;
        }
    ?>
</center>
      <form class="form-horizontal" method="post" action="<?php echo $this->uri->baseUri;?>user/prosesinput">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="input01">Username</label>
            <div class="controls">
                <input type="text" class="input-xlarge" id="input01" name="username" title="Silahkan edit" >                  
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Password</label>
            <div class="controls">
                    <input type="text" class="input-xlarge" id="input01" name="password" title="Isikan Password anda.">
                
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="input01">Ulangi Password Baru</label>
            <div class="controls">
                    <input type="text" class="input-xlarge" id="input01" name="password2" title="Isikan ulang Password anda.">
                
            </div>
          </div>
            
            <div class="control-group">
            <label class="control-label" for="select01">Grup</label>
            <div class="controls">
              <select id="select01" name="grup">
                  <option value="0">---= Silahkan pilih grup =---</option>
                  <?php if ($grup){
                      foreach ($grup as $grup){
                          ?>
                  <option value="<?php echo $grup->grup;?>"><?php echo $grup->grup;?></option>
                  
                  <?php
                      }
                  }
                    ?>
              </select>
            </div>
          </div>
            
          <div class="form-actions">
              
              <button type="submit" class="btn btn-primary">Save</button>
              
              <input type="button" class="btn btn-danger" value="Kembali" onclick="location.href='<?php echo $this->uri->baseUri;?>user'" />
          </div>
        </fieldset>
      </form>