<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php echo $title;?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="<?php echo $this->uri->baseUri;?>style/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo $this->uri->baseUri;?>style/css/table.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
    </style>
    <link href="<?php echo $this->uri->baseUri;?>style/css/bootstrap-responsive.css" rel="stylesheet">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo $this->uri->baseUri;?>style/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $this->uri->baseUri;?>style/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $this->uri->baseUri;?>style/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $this->uri->baseUri;?>style/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo $this->uri->baseUri;?>style/ico/apple-touch-icon-57-precomposed.png">
        <?php if (isset($refresh)){
                ?>
    <meta http-equiv="REFRESH" content="20;url=<?php echo $refresh;?>">
    <?php
            
        }
    ?>
            
            <?php if (isset($chart)){
                 $this->output(TMP.$chart);
                    }
                    ?>
<!-- AUTO COMPLETE -->
             <script type="text/javascript" src="<?php echo $this->uri->baseUri;?>style/js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->uri->baseUri;?>style/js/jquery-ui-1.8.21.custom.min.js"></script>
      <link href="<?php echo $this->uri->baseUri;?>style/js/themes/jquery-ui-1.8.21.custom.css" rel="stylesheet">          
      <link href="<?php echo $this->uri->baseUri;?>style/js/themes/jquery.ui.autocomplete.css" rel="stylesheet">
      <script type="text/javascript">
jQuery.noConflict();
</script>
          
           <?php if (isset($auto)){  $this->output(TMP.$auto); } ?>

    <!-- JS Batas sms -->
    <?php if (isset($batassms)){$this->output(TMP.'jspesan');}?>
         
  </head>
