<script>
            jQuery(function()
            {
            var sanca =[
                <?php if (isset($phonebook)){
                    foreach ($phonebook as $phonebook){ ?>
                                "<?php echo $phonebook->Name;?>",
                        <?php
                    }  
                }?>
            ];
            
            
            jQuery("#auto").autocomplete({
                source: sanca,
                minLength: 0,
                close: function () {
            jQuery.ajax(
                {
                type: 'POST',
                url: '<?php echo $this->uri->baseUri;?>fungsijs/notlp',
                data: {nama: jQuery('#auto').val()},
                success: function(data) {
      			jQuery('[id$=notlp]').val(data);
                    }
                }
                   )
                }
            
            });
            
            });

</script>