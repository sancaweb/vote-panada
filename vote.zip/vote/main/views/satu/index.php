<?php $this->output(TMP.'header');?>
  <body <?php if (isset($batassms)){echo 'onload="initial()"';}?>>
    <div class="navbar navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <a class="brand" href="<?php echo $this->uri->baseUri;?>"><i>SANCA SMS GATEWAY V.01</i></a>
          
          <div class="nav-collapse">
              <?php
          if($this->session->getValue('username')==TRUE AND $this->session->getValue('kode')==md5('sanca')) {
          ?>
            <ul class="nav" role="navigation">
                    <li class="dropdown">
                      <a id="drop1" href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Pesan <b class="caret"></b></a>
                      <ul class="dropdown-menu" role="menu" aria-labelledby="drop1">
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>sms">Kirim Pesan</a></li>
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>sms/broadcast">Broadcast</a></li>
                          <li class="divider"></li>
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>inbox">Inbox</a></li>
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>outbox">Outbox</a></li>
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>sentitems">Pesan Terkirim</a></li>
                        
                      </ul>
                    </li>
                    
                    <li class="dropdown">
                      <a href="#" id="drop2" role="button" class="dropdown-toggle" data-toggle="dropdown">Phonebook <b class="caret"></b></a>
                      <ul class="dropdown-menu" role="menu" aria-labelledby="drop2">
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>phonebook">View Phonebook</a></li>
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>phonebook/input">Input Phonebook</a></li>
                        <li class="divider"></li>                        
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>grup">Phonebook Group</a></li>
                        
                      </ul>
                    </li>
                  </ul>
                  <ul class="nav pull-right">
                    <li id="fat-menu" class="dropdown">
                      <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">User <b class="caret"></b></a>
                      <ul class="dropdown-menu" role="menu" aria-labelledby="drop3">
                          <li><a tabindex="-1">You Are <?php echo $this->session->getValue('username')?></a></li>
                          <li class="divider"></li>  
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>user">View User</a></li>
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>user/input">Insert User</a></li>
                          <li class="divider"></li>  
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>login/logout">Logout</a></li>                        
                      </ul>
                    </li>
                  </ul>
                  <ul class="nav pull-right">
                    <li id="fat-menu" class="dropdown">
                      <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">Vote <b class="caret"></b></a>
                      <ul class="dropdown-menu" role="menu" aria-labelledby="drop3">
                          <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>sms/vote">View hasil Vote</a></li>
                        <li><a tabindex="-1" href="<?php echo $this->uri->baseUri;?>setvote">Settings</a></li>
                      </ul>
                    </li>
                  </ul>
              <?php }else{
                  echo '
                      <ul class="nav pull-right">
                    <li id="fat-menu" class="dropdown">
                      <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">User <b class="caret"></b></a>
                      <ul class="dropdown-menu" role="menu" aria-labelledby="drop3">
                          <li><a tabindex="-1" href="'.$this->uri->baseUri.'login">Login</a></li>                        
                      </ul>
                    </li>
                  </ul>
                        ';
              }
          ?>
          </div>
          
          
          <!--/.nav-collapse -->
        </div>
      </div>
    </div>

    <div class="container" >

      <!-- Main hero unit for a primary marketing message or call to action -->
      
      <div class="hero-unit">
          
        <?php if (isset($konten)){
            $this->output(TMP.$konten);
            
        }
            ?>
      </div>
      
      
      <!-- TEST MODAL -->
      <?php
      if (isset($modal)){
          $this->output(TMP.$modal."modal1");
          $this->output(TMP.$modal."modal2");
          $this->output(TMP.$modal."modal3");
          
      }
          ?>
      
      <!-- END MODAL -->

      <!-- Example row of columns -->
      
      <?php 
      if (isset($column)){
          $this->output(TMP.$column);
          
      }
      ?>
      <!-- Columns -->

      <hr>

      <?php $this->output(TMP.'footer');?>