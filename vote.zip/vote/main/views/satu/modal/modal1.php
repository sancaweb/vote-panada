<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<div class="modal hide" id="modal1">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h3>SMS Gateway</h3>
  </div>
  <div class="modal-body">
      <center><img src="<?php echo $this->uri->baseUri;?>aset/img/sms.jpg" /></center>
    <p>
- Mengirim SMS pada satu nomer, dengan menggunakan form auto complete yang memudahkan kita untuk melakukan pencarian nomer pada Phonebook.
<br/>
- Mengirim SMS pada beberapa nomer telpon berdasarkan kategori nomer telepon, cocok untuk promosi maupun pemberitahuan secara masal menggunakan SMS.
<br/>
- Fasilitas SMS Vote/ Polling (akan di jelaskan selengkapnya pada tulisan berikutnya)
<br/>
- View dan delete Inbox, Outbox dan Sentitems
    </p>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Close</a>
    <!--
    <a href="#" class="btn btn-primary">Save changes</a>
    -->
  </div>
</div>