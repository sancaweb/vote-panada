<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<div class="modal hide" id="modal3">
  <div class="modal-header3">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h3>Phonebook Management</h3>
  </div>
  <div class="modal-body">
      <center><img src="<?php echo $this->uri->baseUri;?>aset/img/phonebook.png" height=200"/></center>
      <br />
      <p>
        - Input, hapus, view dan edit phonebook.
        <br/>
        - Input, edit dan hapus grup phonebook.
        <br/>
    </p>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Close</a>
  </div>
</div>