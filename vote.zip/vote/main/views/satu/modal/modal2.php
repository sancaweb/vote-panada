<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<div class="modal hide" id="modal2">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h3>SMS Vote/Polling</h3>
  </div>
  <div class="modal-body">
      <p><center><img src="<?php echo $this->uri->baseUri;?>aset/img/chart.png"/></center>
        - Menentukan Format Prefix (kata awal) yang akan digunakan untuk SMS Vote/Polling.
        <br/>
        - Menentukan pilihan yang akan digunakan untuk SMS Vote/Polling.
        <br/>
        - View, Edit dan hapus pilihan
        <br/>
        - Mengatur aktif atau tidaknya polling.
        <br/>
        - Melihat hasil Vote/Polling yang interaktif dan elegant.
        <br/>
        - Export grafik hasil Vote/Polling menjadi image.
        <br/>
        - Print grafik hasil Vote/Polling.
        <br/>
        - Filtering number option: Dapat di atur apakah sistem voting mau diberlakukan adanya filtering number sehingga menjadi 1 vote 1 number atau tidak ada filter number.
    </p>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Close</a>
  </div>
</div>