<!--
This program created by Sanca, Visit my homepage at: http://sanca.web.id
 or email me at: sanca.snake@gmail.com
-->
<footer>
        <p>&copy; Company 2012</p>
      </footer>

    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-transition.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-alert.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-modal.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-tab.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-popover.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-button.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-collapse.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-carousel.js"></script>
    <script src="<?php echo $this->uri->baseUri;?>style/js/bootstrap-typeahead.js"></script>
    
  </body>
</html>