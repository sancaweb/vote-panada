        <legend><h2>Phonebook Management</h2></legend>
           <p>Di dalam aplikasi sms Gateway, phonebook mungkin bisa dijadikan sebagai fitur wajib. Karena akan memudahkan bagi pengguna untuk menyimpan beberapa nomer yang sudah terhubung. Dan beberapa nomer telpon yang sudah tersimpan pun akan bisa dimanfaatan kembali suatu saat nanti jika diperlukan.</p>
            <p>
            Di dalam aplikasi <b>"Sanca SMS Gateway V.01"</b> ini pun pengguna dapat melakukan pengaturan pada phonebook yang disediakan. Adapun beberapa fitur yang ada pada phonebook, dapat dilihat dibawah ini.
            </p>
          <p><a class="btn" data-toggle="modal" href="#modal3">View details &raquo;</a></p>
        