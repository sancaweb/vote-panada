        <legend><h2>SMS Vote/Polling</h2></legend>
           <p>
               Aplikasi yang bernama <b>Sanca SMS Gateway V.01</b> inipun memiliki fasilitas SMS Vote/Polling. SMS Vote/Polling dapat membantu anda untuk mendapatkan hasil dari sebuah survey, baik itu survey tentang kekuatan caln-calon Kepala Pemerintahan maupun survey apapun yang membutuhkan hasil yang tepat dan cepet. Adapun beberapa fasilitas pendukung untuk SMS Vote/Polling ini sebagai berikut :
            </p>
          <p><a class="btn" data-toggle="modal" href="#modal2">View details &raquo;</a></p>
        