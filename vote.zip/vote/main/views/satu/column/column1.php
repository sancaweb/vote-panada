        <legend><h2>SMS Gateway</h2></legend>
           <p align="justify">
               Pada dunia komputer, gateway dapat berarti juga sebagai jembatan penghubung antar satu sistem dengan sistem lain yang berbeda, sehingga dapat terjadi suatu pertukaran data antar sistem tersebut. Dengan demikian, SMS gateway dapat diartikan sebagai suatu penghubung untuk lalu lintas data-data SMS, baik yang dikirimkan maupun yang diterima. Selain aplikasi yang dapat melakukan komunikasi berupada SMS, pada aplikasi <b>"Sanca SMS Gateway V.01"</b> ini pun dilengkapi fasilitas untuk manajemen buku telepon. Untuk lebih lengkapnya terdapat beberapa fasilitas seperti dibawah ini :
               
               
           </p>
          <p><a class="btn" data-toggle="modal" href="#modal1">View details &raquo;</a></p>
        