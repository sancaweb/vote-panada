<script type="text/javascript">

var maxChar = 160;

function count()
{
  if (document.formsms.text.value.length > maxChar)
  {
     document.formsms.text.value =  document.formsms.text.value.substring(0, maxChar);
     alert("SMS yang anda masukan melebihi batas maksimum");
  }
  else document.formsms.counter.value = maxChar - document.formsms.text.value.length;
}

function initial()
{
   document.formsms.counter.value = maxChar;
}

</script>